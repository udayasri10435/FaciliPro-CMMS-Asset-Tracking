import React, { useState } from 'react';
import { useCMMS } from '../context/CMMSContext';
import { SparePart } from '../types/cmms';
import {
  Box,
  Search,
  Filter,
  AlertTriangle,
  Plus,
  RefreshCw,
  ShoppingBag,
  TrendingDown,
  CheckCircle2,
  DollarSign,
} from 'lucide-react';

export const InventoryView: React.FC = () => {
  const { spareParts, currentFacility, reorderSparePart, showToast } = useCMMS();

  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');

  const facilityParts = spareParts.filter((p) => p.facilityId === currentFacility.id);

  const categories = Array.from(new Set(facilityParts.map((p) => p.category)));

  const filteredParts = facilityParts.filter((part) => {
    const matchesSearch =
      part.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      part.partNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      part.binLocation.toLowerCase().includes(searchQuery.toLowerCase()) ||
      part.supplier.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesCategory = categoryFilter === 'all' || part.category === categoryFilter;

    return matchesSearch && matchesCategory;
  });

  const lowStockCount = facilityParts.filter((p) => p.quantityInStock <= p.minReorderPoint).length;
  const totalValuation = facilityParts.reduce(
    (acc, p) => acc + p.quantityInStock * p.unitCost,
    0
  );

  return (
    <div className="space-y-6 pb-12">
      {/* Header Metric Strip */}
      <section className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="rounded-lg border border-neutral-800 bg-neutral-900/80 p-4">
          <div className="text-[11px] font-medium text-neutral-400">Total SKUs Tracked</div>
          <div className="mt-1 text-2xl font-bold text-white font-mono tabular-nums">
            {facilityParts.length}
          </div>
          <div className="text-[10px] text-neutral-500 mt-1">Dedicated facility storage bins</div>
        </div>

        <div className="rounded-lg border border-neutral-800 bg-neutral-900/80 p-4">
          <div className="text-[11px] font-medium text-neutral-400">Inventory Valuation</div>
          <div className="mt-1 text-2xl font-bold text-amber-400 font-mono tabular-nums">
            ${totalValuation.toLocaleString(undefined, { minimumFractionDigits: 2 })}
          </div>
          <div className="text-[10px] text-neutral-500 mt-1">Carrying replacement cost</div>
        </div>

        <div className="rounded-lg border border-neutral-800 bg-neutral-900/80 p-4">
          <div className="text-[11px] font-medium text-neutral-400">Safety Stock Alerts</div>
          <div className="mt-1 text-2xl font-bold font-mono tabular-nums flex items-center gap-2">
            <span className={lowStockCount > 0 ? 'text-rose-400' : 'text-emerald-400'}>
              {lowStockCount}
            </span>
            {lowStockCount > 0 && (
              <span className="text-xs font-semibold text-rose-400 bg-rose-500/10 px-2 py-0.5 rounded border border-rose-500/20">
                Action Required
              </span>
            )}
          </div>
          <div className="text-[10px] text-neutral-500 mt-1">
            {lowStockCount > 0 ? 'Critical components below reorder point' : 'All buffer stocks nominal'}
          </div>
        </div>
      </section>

      {/* Filter and Search Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 bg-neutral-900/60 p-4 rounded-lg border border-neutral-800">
        <div className="flex flex-1 items-center gap-3">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-neutral-500" />
            <input
              type="text"
              placeholder="Search part #, name, supplier, bin location..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-neutral-950 border border-neutral-800 rounded-md pl-9 pr-3 py-1.5 text-xs text-neutral-200 placeholder-neutral-500 focus:outline-none focus:border-amber-500"
            />
          </div>

          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="bg-neutral-950 border border-neutral-800 rounded-md px-2.5 py-1.5 text-xs text-neutral-300 focus:outline-none focus:border-amber-500"
          >
            <option value="all">All Categories</option>
            {categories.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Inventory Table */}
      <div className="rounded-lg border border-neutral-800 bg-neutral-900/70 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-neutral-950/80 text-neutral-400 border-b border-neutral-800 text-[11px] font-semibold uppercase tracking-wider">
              <tr>
                <th className="py-3 px-4">Part #</th>
                <th className="py-3 px-4">Part Description</th>
                <th className="py-3 px-4">Category</th>
                <th className="py-3 px-4">Bin Location</th>
                <th className="py-3 px-4">Stock Level</th>
                <th className="py-3 px-4">Unit Cost</th>
                <th className="py-3 px-4">Supplier</th>
                <th className="py-3 px-4 text-right">Quick Restock</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-800/60">
              {filteredParts.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-neutral-500">
                    No spare parts found in current inventory.
                  </td>
                </tr>
              ) : (
                filteredParts.map((part) => {
                  const isLow = part.quantityInStock <= part.minReorderPoint;

                  return (
                    <tr
                      key={part.id}
                      className="hover:bg-neutral-800/40 transition-colors"
                    >
                      <td className="py-3 px-4 font-mono font-bold text-amber-400 whitespace-nowrap">
                        {part.partNumber}
                      </td>
                      <td className="py-3 px-4">
                        <div className="font-semibold text-white">{part.name}</div>
                        <div className="text-[11px] text-neutral-400 font-mono">
                          Lead Time: {part.leadTimeDays} days
                        </div>
                      </td>
                      <td className="py-3 px-4 text-neutral-300 whitespace-nowrap">
                        {part.category}
                      </td>
                      <td className="py-3 px-4 font-mono text-neutral-300 whitespace-nowrap">
                        {part.binLocation}
                      </td>
                      <td className="py-3 px-4 whitespace-nowrap">
                        <div className="flex items-center gap-2">
                          <span
                            className={`font-mono text-sm font-bold tabular-nums ${
                              isLow ? 'text-rose-400' : 'text-neutral-200'
                            }`}
                          >
                            {part.quantityInStock}
                          </span>
                          <span className="text-[11px] text-neutral-500 font-mono">
                            (Min: {part.minReorderPoint})
                          </span>
                        </div>
                        {isLow && (
                          <div className="text-[10px] text-rose-400 font-semibold mt-0.5">
                            LOW SAFETY STOCK
                          </div>
                        )}
                      </td>
                      <td className="py-3 px-4 font-mono text-neutral-200 tabular-nums whitespace-nowrap">
                        ${part.unitCost.toFixed(2)}
                      </td>
                      <td className="py-3 px-4 text-neutral-400 whitespace-nowrap">
                        {part.supplier}
                      </td>
                      <td className="py-3 px-4 text-right whitespace-nowrap">
                        <button
                          onClick={() => reorderSparePart(part.id, 5)}
                          className="px-2.5 py-1 bg-neutral-800 hover:bg-neutral-700 text-amber-400 hover:text-amber-300 font-semibold rounded text-xs transition-colors border border-neutral-700"
                        >
                          +5 Reorder
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
