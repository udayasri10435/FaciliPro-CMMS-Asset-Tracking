import React, { useState } from 'react';
import { useCMMS } from '../context/CMMSContext';
import {
  Calendar,
  Clock,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  Play,
  FileCheck,
  Filter,
  CheckSquare,
  ArrowRight,
} from 'lucide-react';

export const PreventiveMaintenanceView: React.FC = () => {
  const {
    preventiveSchedules,
    currentFacility,
    generateWorkOrderFromPM,
    setSelectedWorkOrderId,
    setIsComplianceReportOpen,
  } = useCMMS();

  const [frequencyFilter, setFrequencyFilter] = useState<string>('all');

  const facilityPMs = preventiveSchedules.filter((p) => p.facilityId === currentFacility.id);

  const filteredPMs = facilityPMs.filter((p) => {
    if (frequencyFilter === 'all') return true;
    return p.frequency.toLowerCase() === frequencyFilter.toLowerCase();
  });

  const handleTriggerWO = (pmId: string) => {
    const created = generateWorkOrderFromPM(pmId);
    setSelectedWorkOrderId(created.id);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Compliance Standard Header Banner */}
      <section className="rounded-lg border border-neutral-800 bg-neutral-900/60 p-5 backdrop-blur-sm">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-xs text-neutral-400">
              <span className="text-amber-400 font-semibold">{currentFacility.complianceBody}</span>
              <span aria-hidden="true">·</span>
              <span>Regulatory Governance</span>
            </div>
            <h2 className="text-lg sm:text-xl font-bold text-white">
              Preventive Maintenance & Compliance Engine
            </h2>
            <p className="text-xs text-neutral-400">
              Mandatory inspection cadence governing {currentFacility.name} under standard{' '}
              <strong className="text-neutral-300 font-semibold">{currentFacility.complianceStandard}</strong>.
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <div className="rounded-md border border-emerald-900/40 bg-emerald-950/20 px-3 py-2 text-right">
              <div className="text-[10px] text-emerald-400 font-medium uppercase tracking-wider">
                Audited Compliance
              </div>
              <div className="text-xl font-bold text-emerald-400 font-mono tabular-nums">
                {currentFacility.pmComplianceRate}%
              </div>
            </div>

            <button
              onClick={() => setIsComplianceReportOpen(true)}
              className="flex items-center gap-2 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 px-3 py-2 rounded-md text-xs font-medium transition-colors"
            >
              <FileCheck className="h-4 w-4 text-emerald-400" />
              <span>Inspection Dossier</span>
            </button>
          </div>
        </div>
      </section>

      {/* Filter Tabs */}
      <div className="flex items-center justify-between gap-2 border-b border-neutral-800 pb-3">
        <div className="flex items-center gap-1.5 overflow-x-auto py-1">
          {['all', 'daily', 'weekly', 'monthly', 'quarterly', 'annual'].map((freq) => (
            <button
              key={freq}
              onClick={() => setFrequencyFilter(freq)}
              className={`px-3 py-1.5 rounded-md text-xs font-medium capitalize transition-colors whitespace-nowrap ${
                frequencyFilter === freq
                  ? 'bg-amber-500 text-neutral-950 font-semibold'
                  : 'text-neutral-400 hover:bg-neutral-800 hover:text-white'
              }`}
            >
              {freq}
            </button>
          ))}
        </div>

        <span className="text-xs text-neutral-500 font-mono">
          {filteredPMs.length} Active PM Schedules
        </span>
      </div>

      {/* PM Schedules Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredPMs.length === 0 ? (
          <div className="col-span-2 rounded-lg border border-neutral-800 bg-neutral-900/40 p-12 text-center text-neutral-500 text-xs">
            No preventive maintenance schedules found for this frequency.
          </div>
        ) : (
          filteredPMs.map((pm) => {
            const isDueSoon = pm.status === 'due_soon';

            return (
              <div
                key={pm.id}
                className="rounded-lg border border-neutral-800 bg-neutral-900/80 p-5 space-y-4 hover:border-neutral-700 transition-all flex flex-col justify-between"
              >
                <div className="space-y-3">
                  {/* Top Line */}
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="flex items-center gap-2 text-xs font-mono">
                        <span className="text-amber-400 font-bold">{pm.pmCode}</span>
                        <span aria-hidden="true" className="text-neutral-600">·</span>
                        <span className="text-neutral-300 font-medium">{pm.frequency} Recurrence</span>
                      </div>
                      <h3 className="text-sm font-bold text-white mt-1">
                        {pm.title}
                      </h3>
                    </div>

                    <span
                      className={`text-[10px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded ${
                        isDueSoon
                          ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                          : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                      }`}
                    >
                      {pm.status.replace('_', ' ')}
                    </span>
                  </div>

                  {/* Asset & Role Details */}
                  <div className="text-xs space-y-1 bg-neutral-950/60 p-3 rounded border border-neutral-800/80">
                    <div className="flex justify-between">
                      <span className="text-neutral-500">Asset:</span>
                      <span className="text-neutral-200 font-medium truncate max-w-[240px]">
                        [{pm.assetTag}] {pm.assetName}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-neutral-500">Assigned Craft:</span>
                      <span className="text-neutral-300">{pm.assignedRole}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-neutral-500">Est. Time:</span>
                      <span className="font-mono text-neutral-300">{pm.estimatedMinutes} minutes</span>
                    </div>
                    <div className="flex justify-between border-t border-neutral-800/80 pt-1 mt-1">
                      <span className="text-neutral-500">Standard:</span>
                      <span className="text-neutral-400 font-mono text-[11px] truncate max-w-[240px]">
                        {pm.complianceStandard}
                      </span>
                    </div>
                  </div>

                  {/* Task List */}
                  <div className="space-y-1.5">
                    <div className="text-[11px] font-medium text-neutral-400 uppercase tracking-wider">
                      Standard Inspection Checklist:
                    </div>
                    <ul className="space-y-1 text-xs text-neutral-300">
                      {pm.tasks.map((task, idx) => (
                        <li key={idx} className="flex items-start gap-2">
                          <CheckCircle2 className="h-3.5 w-3.5 text-neutral-600 mt-0.5 shrink-0" />
                          <span>{task}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                {/* Footer / Trigger WO Action */}
                <div className="pt-3 border-t border-neutral-800/80 flex items-center justify-between">
                  <div className="text-[11px] text-neutral-500 font-mono">
                    Next Due: <strong className="text-neutral-300">{pm.nextDueDate}</strong>
                  </div>

                  <button
                    onClick={() => handleTriggerWO(pm.id)}
                    className="flex items-center gap-1.5 bg-amber-500 hover:bg-amber-400 text-neutral-950 font-semibold px-3 py-1.5 rounded text-xs transition-colors shadow-sm"
                  >
                    <Play className="h-3.5 w-3.5 fill-current" />
                    <span>Generate & Dispatch WO</span>
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
