import React, { useState } from 'react';
import { useCMMS } from '../context/CMMSContext';
import {
  Smartphone,
  QrCode,
  Wrench,
  CheckCircle2,
  Clock,
  Mic,
  PenTool,
  CheckSquare,
  AlertTriangle,
  ArrowLeft,
  ChevronRight,
  Wifi,
  MapPin,
  Play,
  Pause,
  User,
} from 'lucide-react';

export const TechnicianMobileView: React.FC = () => {
  const {
    currentFacility,
    workOrders,
    technicians,
    setIsMobileFieldMode,
    setIsQrScannerOpen,
    setSelectedWorkOrderId,
    updateWorkOrderStatus,
    toggleChecklistItem,
    logLaborHours,
    signOffWorkOrder,
    showToast,
  } = useCMMS();

  const [selectedTechId, setSelectedTechId] = useState<string>(technicians[0].id);
  const [activeWoDetailId, setActiveWoDetailId] = useState<string | null>(null);
  const [isRecordingNote, setIsRecordingNote] = useState(false);
  const [mobileSignerName, setMobileSignerName] = useState('');
  const [showSignInput, setShowSignInput] = useState(false);
  const [isTimerRunning, setIsTimerRunning] = useState(false);

  const currentTech = technicians.find((t) => t.id === selectedTechId) || technicians[0];

  // Filter WOs for current facility and this technician
  const myOrders = workOrders.filter(
    (wo) => wo.facilityId === currentFacility.id && wo.assignedTechnician.id === currentTech.id
  );

  const activeWo = workOrders.find((w) => w.id === activeWoDetailId);

  const handleVoiceNote = () => {
    setIsRecordingNote(true);
    showToast('Microphone active: Transcribing audio note...');
    setTimeout(() => {
      setIsRecordingNote(false);
      showToast('Audio note transcribed: "Replaced belt tensioner. Vibration amplitude reduced to 0.12 in/s."');
    }, 2200);
  };

  const handleToggleTimer = (woId: string) => {
    if (!isTimerRunning) {
      setIsTimerRunning(true);
      showToast('Field timer started: Tracking active labor...');
    } else {
      setIsTimerRunning(false);
      logLaborHours(woId, 0.5);
      showToast('Field timer stopped: +0.5h logged to ticket');
    }
  };

  const handleMobileSignOff = (woId: string) => {
    if (!mobileSignerName.trim()) return;
    signOffWorkOrder(woId, mobileSignerName.trim());
    setShowSignInput(false);
    setMobileSignerName('');
  };

  return (
    <div className="mx-auto max-w-md w-full min-h-[85vh] bg-neutral-950 border border-neutral-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col my-4">
      {/* Mobile Top App Bar */}
      <div className="bg-neutral-900 border-b border-neutral-800 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="text-xs font-bold tracking-tight text-white uppercase font-mono">
            Field Mobile Tech
          </span>
          <span className="text-[10px] text-neutral-400 font-mono">(Offline Synced)</span>
        </div>

        <button
          onClick={() => setIsMobileFieldMode(false)}
          className="text-xs text-amber-400 font-medium hover:underline flex items-center gap-1"
        >
          <span>Exit Mobile</span>
        </button>
      </div>

      {/* Technician Badge & Quick Switcher */}
      <div className="bg-neutral-900/60 p-3 border-b border-neutral-800 flex items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2 truncate">
          <div className="h-8 w-8 rounded-full bg-amber-500/20 text-amber-400 font-bold flex items-center justify-center shrink-0 border border-amber-500/40">
            {currentTech.name.charAt(0)}
          </div>
          <div className="truncate">
            <div className="font-bold text-white truncate">{currentTech.name}</div>
            <div className="text-[11px] text-neutral-400 truncate">{currentTech.role}</div>
          </div>
        </div>

        <select
          value={selectedTechId}
          onChange={(e) => setSelectedTechId(e.target.value)}
          className="bg-neutral-950 border border-neutral-800 rounded px-2 py-1 text-[11px] text-neutral-300 focus:outline-none"
        >
          {technicians.map((t) => (
            <option key={t.id} value={t.id}>
              {t.name.split(' ')[0]} ({t.role.split(' ')[0]})
            </option>
          ))}
        </select>
      </div>

      {/* Big Action Button: Scan QR at Equipment */}
      <div className="p-3 bg-neutral-950">
        <button
          onClick={() => setIsQrScannerOpen(true)}
          className="w-full py-3 px-4 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-neutral-950 font-bold rounded-xl text-sm flex items-center justify-center gap-2.5 shadow-lg active:scale-98 transition-all"
        >
          <QrCode className="h-5 w-5" />
          <span>Scan Machine QR in Field</span>
        </button>
      </div>

      {/* Main Body: Active WO detail OR Dispatched Queue */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {activeWo ? (
          /* Active Work Order Mobile Detail View */
          <div className="space-y-4">
            <button
              onClick={() => setActiveWoDetailId(null)}
              className="flex items-center gap-1.5 text-xs text-neutral-400 hover:text-white mb-2"
            >
              <ArrowLeft className="h-4 w-4" />
              <span>Back to My Queue</span>
            </button>

            {/* WO Header */}
            <div className="rounded-xl border border-neutral-800 bg-neutral-900 p-4 space-y-2">
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-amber-400 font-bold">{activeWo.woNumber}</span>
                <span className={`uppercase font-bold text-[10px] px-2 py-0.5 rounded ${
                  activeWo.priority === 'emergency' ? 'bg-rose-500/20 text-rose-300' : 'bg-amber-500/20 text-amber-300'
                }`}>
                  {activeWo.priority}
                </span>
              </div>
              <h2 className="text-base font-bold text-white">{activeWo.title}</h2>
              <div className="text-xs text-neutral-400 flex items-center gap-1">
                <MapPin className="h-3.5 w-3.5 text-neutral-500 shrink-0" />
                <span>{activeWo.location}</span>
              </div>
            </div>

            {/* Quick Labor Timer Bar */}
            <div className="rounded-xl border border-neutral-800 bg-neutral-900 p-3 flex items-center justify-between">
              <div>
                <div className="text-[11px] text-neutral-400">Labor Timer</div>
                <div className="font-mono text-sm font-bold text-white">
                  {activeWo.laborHoursLogged}h Total Logged
                </div>
              </div>

              <button
                onClick={() => handleToggleTimer(activeWo.id)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  isTimerRunning
                    ? 'bg-rose-600 text-white animate-pulse'
                    : 'bg-neutral-800 text-neutral-200 hover:bg-neutral-700'
                }`}
              >
                {isTimerRunning ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4 fill-current" />}
                <span>{isTimerRunning ? 'Stop Timer' : 'Start Timer'}</span>
              </button>
            </div>

            {/* Interactive Field Checklist */}
            <div className="rounded-xl border border-neutral-800 bg-neutral-900 p-4 space-y-3">
              <div className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-1.5 font-bold text-white">
                  <CheckSquare className="h-4 w-4 text-amber-400" />
                  <span>Field Task Checklist</span>
                </div>
                <span className="font-mono text-neutral-400">
                  {activeWo.checklist.filter((c) => c.completed).length}/{activeWo.checklist.length}
                </span>
              </div>

              <div className="space-y-2">
                {activeWo.checklist.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => toggleChecklistItem(activeWo.id, item.id)}
                    className={`w-full flex items-start gap-3 p-3 rounded-lg border text-left text-xs transition-colors ${
                      item.completed
                        ? 'bg-neutral-950/60 border-neutral-800 text-neutral-500 line-through'
                        : 'bg-neutral-950 border-neutral-800 text-neutral-200 active:border-amber-500'
                    }`}
                  >
                    <div
                      className={`h-5 w-5 rounded mt-0.5 flex items-center justify-center border shrink-0 ${
                        item.completed
                          ? 'bg-amber-500 border-amber-400 text-neutral-950'
                          : 'border-neutral-700 bg-neutral-900'
                      }`}
                    >
                      {item.completed && <CheckCircle2 className="h-4 w-4 stroke-[3]" />}
                    </div>
                    <span className="leading-tight">{item.task}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Quick Voice Note Input */}
            <div className="rounded-xl border border-neutral-800 bg-neutral-900 p-3 flex items-center justify-between">
              <div>
                <div className="text-xs font-bold text-white">Voice Note / Audio Log</div>
                <div className="text-[11px] text-neutral-400">Dictate hands-free diagnosis</div>
              </div>

              <button
                onClick={handleVoiceNote}
                className={`p-2.5 rounded-full transition-all ${
                  isRecordingNote
                    ? 'bg-rose-600 text-white animate-bounce'
                    : 'bg-neutral-800 text-neutral-300 hover:bg-neutral-700'
                }`}
              >
                <Mic className="h-5 w-5" />
              </button>
            </div>

            {/* Status Change & Sign-off */}
            <div className="space-y-2 pt-2">
              {activeWo.status !== 'completed' && activeWo.status !== 'verified' && (
                <button
                  onClick={() => updateWorkOrderStatus(activeWo.id, 'completed')}
                  className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs transition-colors flex items-center justify-center gap-2"
                >
                  <CheckCircle2 className="h-4 w-4" />
                  <span>Mark Work Completed</span>
                </button>
              )}

              {activeWo.status === 'completed' && !activeWo.signedOffBy && (
                <div>
                  {!showSignInput ? (
                    <button
                      onClick={() => setShowSignInput(true)}
                      className="w-full py-3 bg-purple-600 hover:bg-purple-500 text-white font-bold rounded-xl text-xs transition-colors flex items-center justify-center gap-2"
                    >
                      <PenTool className="h-4 w-4" />
                      <span>Capture Customer / Lead Sign-Off</span>
                    </button>
                  ) : (
                    <div className="rounded-xl border border-neutral-800 bg-neutral-900 p-3 space-y-2">
                      <div className="text-xs text-neutral-300 font-medium">Inspector / Client Signature Name:</div>
                      <input
                        type="text"
                        placeholder="Print Full Name..."
                        value={mobileSignerName}
                        onChange={(e) => setMobileSignerName(e.target.value)}
                        className="w-full bg-neutral-950 border border-neutral-800 rounded px-3 py-2 text-xs text-white focus:outline-none focus:border-purple-500"
                      />
                      <div className="flex gap-2">
                        <button
                          onClick={() => handleMobileSignOff(activeWo.id)}
                          className="flex-1 py-2 bg-purple-600 hover:bg-purple-500 text-white font-bold rounded text-xs"
                        >
                          Sign & Close Ticket
                        </button>
                        <button
                          onClick={() => setShowSignInput(false)}
                          className="px-3 py-2 bg-neutral-800 text-neutral-400 rounded text-xs"
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        ) : (
          /* Dispatched Work Orders Queue for this Technician */
          <div className="space-y-3">
            <div className="flex items-center justify-between text-xs text-neutral-400">
              <span className="font-semibold uppercase tracking-wider">
                My Dispatched Tickets ({myOrders.length})
              </span>
              <span>{currentFacility.name.split(' ')[0]}</span>
            </div>

            {myOrders.length === 0 ? (
              <div className="p-8 text-center text-xs text-neutral-500 bg-neutral-900 rounded-xl border border-neutral-800">
                <CheckCircle2 className="h-8 w-8 text-emerald-400 mx-auto mb-2" />
                <p className="text-neutral-200 font-bold">No active tickets</p>
                <p className="mt-1">You are all caught up on maintenance tasks!</p>
              </div>
            ) : (
              myOrders.map((wo) => {
                const isEmergency = wo.priority === 'emergency';
                const isUrgent = wo.priority === 'urgent';

                return (
                  <div
                    key={wo.id}
                    onClick={() => setActiveWoDetailId(wo.id)}
                    className="rounded-xl border border-neutral-800 bg-neutral-900 p-4 space-y-2.5 active:scale-99 transition-all cursor-pointer shadow-sm hover:border-neutral-700"
                  >
                    <div className="flex items-center justify-between text-xs font-mono">
                      <span className="text-amber-400 font-bold">{wo.woNumber}</span>
                      <span
                        className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${
                          isEmergency
                            ? 'bg-rose-500/20 text-rose-300'
                            : isUrgent
                            ? 'bg-amber-500/20 text-amber-300'
                            : 'bg-neutral-800 text-neutral-400'
                        }`}
                      >
                        {wo.priority}
                      </span>
                    </div>

                    <h3 className="text-sm font-bold text-white line-clamp-2">
                      {wo.title}
                    </h3>

                    <div className="text-xs text-neutral-400 flex items-center gap-1 truncate">
                      <MapPin className="h-3 w-3 text-neutral-500 shrink-0" />
                      <span className="truncate">{wo.location}</span>
                    </div>

                    <div className="pt-2 border-t border-neutral-800/80 flex items-center justify-between text-[11px] text-neutral-400 font-mono">
                      <span>{wo.checklist.filter((c) => c.completed).length}/{wo.checklist.length} Done</span>
                      <span className="text-amber-400 flex items-center gap-1 font-sans font-semibold">
                        <span>Open Job</span>
                        <ChevronRight className="h-3.5 w-3.5" />
                      </span>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        )}
      </div>
    </div>
  );
};
