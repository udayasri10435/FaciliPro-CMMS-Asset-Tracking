import React, { useState } from 'react';
import { useCMMS } from '../context/CMMSContext';
import { WorkOrderStatus } from '../types/cmms';
import {
  X,
  CheckCircle2,
  Clock,
  Wrench,
  User,
  MapPin,
  AlertTriangle,
  Plus,
  Box,
  PenTool,
  CheckSquare,
  ShieldCheck,
  Building,
} from 'lucide-react';

export const WorkOrderDetailModal: React.FC = () => {
  const {
    selectedWorkOrderId,
    setSelectedWorkOrderId,
    workOrders,
    updateWorkOrderStatus,
    toggleChecklistItem,
    addPartToWorkOrder,
    logLaborHours,
    signOffWorkOrder,
    spareParts,
    currentFacility,
    setSelectedAssetId,
  } = useCMMS();

  const [newChecklistText, setNewChecklistText] = useState('');
  const [selectedPartId, setSelectedPartId] = useState('');
  const [partQty, setPartQty] = useState(1);
  const [additionalLaborHours, setAdditionalLaborHours] = useState('');
  const [signerName, setSignerName] = useState('');
  const [isSigning, setIsSigning] = useState(false);

  if (!selectedWorkOrderId) return null;

  const wo = workOrders.find((w) => w.id === selectedWorkOrderId);
  if (!wo) return null;

  const facilityParts = spareParts.filter((p) => p.facilityId === wo.facilityId);
  const totalPartsCost = wo.partsUsed.reduce(
    (acc, p) => acc + p.quantity * p.unitCost,
    0
  );
  const laborRateEstimate = 85.0; // $85/hr standard facilities rate
  const totalEstimatedCost = totalPartsCost + wo.laborHoursLogged * laborRateEstimate;

  const completedTasks = wo.checklist.filter((c) => c.completed).length;
  const progressPercent =
    wo.checklist.length > 0 ? Math.round((completedTasks / wo.checklist.length) * 100) : 0;

  const handleAddCustomTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newChecklistText.trim()) return;
    const newTask = {
      id: `chk-${Date.now()}`,
      task: newChecklistText.trim(),
      completed: false,
    };
    wo.checklist.push(newTask);
    setNewChecklistText('');
  };

  const handleAllocatePart = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPartId) return;
    addPartToWorkOrder(wo.id, selectedPartId, Number(partQty) || 1);
    setSelectedPartId('');
    setPartQty(1);
  };

  const handleAddLabor = (e: React.FormEvent) => {
    e.preventDefault();
    const hrs = parseFloat(additionalLaborHours);
    if (hrs > 0) {
      logLaborHours(wo.id, hrs);
      setAdditionalLaborHours('');
    }
  };

  const handleSignOffSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!signerName.trim()) return;
    signOffWorkOrder(wo.id, signerName.trim());
    setIsSigning(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-4xl rounded-xl border border-neutral-800 bg-neutral-900 shadow-2xl overflow-hidden my-6 max-h-[90vh] flex flex-col">
        {/* Modal Top Header */}
        <div className="flex items-center justify-between border-b border-neutral-800 px-6 py-4 bg-neutral-950">
          <div className="flex items-center gap-3">
            <span className="font-mono text-sm font-bold text-amber-400">
              {wo.woNumber}
            </span>
            <span aria-hidden="true" className="text-neutral-600">·</span>
            <span className={`text-xs font-semibold uppercase tracking-wider ${
              wo.priority === 'emergency'
                ? 'text-rose-400'
                : wo.priority === 'urgent'
                ? 'text-amber-400'
                : 'text-neutral-400'
            }`}>
              {wo.priority} Priority
            </span>
            <span aria-hidden="true" className="text-neutral-600">·</span>
            <span className="text-xs text-neutral-400 capitalize">{wo.type} WO</span>
          </div>

          <button
            onClick={() => setSelectedWorkOrderId(null)}
            className="rounded-md p-1 text-neutral-400 hover:bg-neutral-800 hover:text-white transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Status Lifecycle Action Bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-neutral-800 px-6 py-2.5 bg-neutral-950/70">
          <div className="flex items-center gap-2">
            <span className="text-xs text-neutral-400">Current Status:</span>
            <span className={`px-2.5 py-0.5 rounded text-xs font-semibold uppercase tracking-wider ${
              wo.status === 'in_progress'
                ? 'bg-blue-500/10 text-blue-400 border border-blue-500/30'
                : wo.status === 'waiting_parts'
                ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                : wo.status === 'completed'
                ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                : wo.status === 'verified'
                ? 'bg-purple-500/10 text-purple-400 border border-purple-500/30'
                : 'bg-neutral-800 text-neutral-300'
            }`}>
              {wo.status.replace('_', ' ')}
            </span>
          </div>

          <div className="flex items-center gap-1.5">
            {wo.status !== 'in_progress' && wo.status !== 'completed' && wo.status !== 'verified' && (
              <button
                onClick={() => updateWorkOrderStatus(wo.id, 'in_progress')}
                className="px-2.5 py-1 text-xs font-medium rounded bg-blue-600 hover:bg-blue-500 text-white transition-colors"
              >
                Start Job
              </button>
            )}

            {wo.status === 'in_progress' && (
              <button
                onClick={() => updateWorkOrderStatus(wo.id, 'waiting_parts')}
                className="px-2.5 py-1 text-xs font-medium rounded bg-amber-600 hover:bg-amber-500 text-white transition-colors"
              >
                Hold for Parts
              </button>
            )}

            {wo.status !== 'completed' && wo.status !== 'verified' && (
              <button
                onClick={() => updateWorkOrderStatus(wo.id, 'completed')}
                className="px-2.5 py-1 text-xs font-medium rounded bg-emerald-600 hover:bg-emerald-500 text-white transition-colors"
              >
                Mark Completed
              </button>
            )}

            {wo.status === 'completed' && !wo.signedOffBy && (
              <button
                onClick={() => setIsSigning(true)}
                className="px-2.5 py-1 text-xs font-medium rounded bg-purple-600 hover:bg-purple-500 text-white transition-colors flex items-center gap-1"
              >
                <PenTool className="h-3 w-3" />
                <span>Sign Off & Close</span>
              </button>
            )}
          </div>
        </div>

        {/* Modal Body Content (Scrollable) */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Main Title & Description */}
          <div className="space-y-2">
            <h2 className="text-lg font-bold text-white tracking-tight">{wo.title}</h2>
            <p className="text-xs sm:text-sm text-neutral-300 leading-relaxed bg-neutral-950 p-3 rounded-md border border-neutral-800">
              {wo.description}
            </p>
          </div>

          {/* Quick Meta Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs bg-neutral-950/60 p-4 rounded-lg border border-neutral-800">
            <div>
              <span className="text-neutral-500 block mb-0.5">Asset Tag & Name</span>
              <button
                onClick={() => {
                  setSelectedAssetId(wo.assetId);
                  setSelectedWorkOrderId(null);
                }}
                className="text-amber-400 hover:underline font-mono font-semibold text-left"
              >
                {wo.assetTag}
              </button>
              <div className="text-neutral-300 truncate">{wo.assetName}</div>
            </div>

            <div>
              <span className="text-neutral-500 block mb-0.5">Location & Zone</span>
              <div className="text-neutral-200 flex items-center gap-1">
                <MapPin className="h-3 w-3 text-neutral-500 shrink-0" />
                <span className="truncate">{wo.location}</span>
              </div>
              <div className="text-neutral-400 text-[11px]">{wo.zone}</div>
            </div>

            <div>
              <span className="text-neutral-500 block mb-0.5">Assigned Specialist</span>
              <div className="text-neutral-200 font-medium flex items-center gap-1">
                <User className="h-3 w-3 text-neutral-500" />
                <span>{wo.assignedTechnician.name}</span>
              </div>
              <div className="text-neutral-400 text-[11px]">{wo.assignedTechnician.role}</div>
            </div>
          </div>

          {/* Checklist Execution Section */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <CheckSquare className="h-4 w-4 text-amber-400" />
                <h3 className="text-xs font-semibold uppercase tracking-wider text-neutral-200">
                  Technician Execution Checklist
                </h3>
              </div>
              <span className="text-xs font-mono text-neutral-400">
                {completedTasks}/{wo.checklist.length} ({progressPercent}%)
              </span>
            </div>

            {/* Visual Progress bar */}
            <div className="h-1.5 w-full bg-neutral-800 rounded-full overflow-hidden">
              <div
                className="h-full bg-amber-500 transition-all duration-300"
                style={{ width: `${progressPercent}%` }}
              />
            </div>

            {/* Checklist items */}
            <div className="space-y-1.5">
              {wo.checklist.map((item) => (
                <label
                  key={item.id}
                  className={`flex items-start gap-3 p-2.5 rounded-md border transition-colors cursor-pointer text-xs ${
                    item.completed
                      ? 'bg-neutral-950/40 border-neutral-800/60 text-neutral-400'
                      : 'bg-neutral-950 border-neutral-800 text-neutral-200 hover:border-neutral-700'
                  }`}
                >
                  <input
                    type="checkbox"
                    checked={item.completed}
                    onChange={() => toggleChecklistItem(wo.id, item.id)}
                    className="mt-0.5 h-4 w-4 rounded border-neutral-700 bg-neutral-900 text-amber-500 focus:ring-amber-500"
                  />
                  <span className={item.completed ? 'line-through text-neutral-500' : ''}>
                    {item.task}
                  </span>
                </label>
              ))}
            </div>

            {/* Add custom checklist step */}
            <form onSubmit={handleAddCustomTask} className="flex gap-2 pt-1">
              <input
                type="text"
                placeholder="Add procedural step to checklist..."
                value={newChecklistText}
                onChange={(e) => setNewChecklistText(e.target.value)}
                className="flex-1 bg-neutral-950 border border-neutral-800 rounded-md px-3 py-1.5 text-xs text-neutral-200 placeholder-neutral-500 focus:outline-none focus:border-amber-500"
              />
              <button
                type="submit"
                className="px-3 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-medium rounded-md transition-colors"
              >
                Add Step
              </button>
            </form>
          </div>

          {/* Parts Used & Labor Logged (Two Column Grid) */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Parts Consumed */}
            <div className="rounded-lg border border-neutral-800 bg-neutral-950 p-4 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-neutral-200">
                  <Box className="h-4 w-4 text-amber-400" />
                  <span>Spare Parts Consumed</span>
                </div>
                <span className="font-mono text-xs text-neutral-400 tabular-nums">
                  ${totalPartsCost.toFixed(2)}
                </span>
              </div>

              <div className="space-y-1.5">
                {wo.partsUsed.length === 0 ? (
                  <div className="text-xs text-neutral-500 italic py-2">
                    No parts logged yet.
                  </div>
                ) : (
                  wo.partsUsed.map((p, idx) => (
                    <div
                      key={idx}
                      className="flex items-center justify-between text-xs border-b border-neutral-800/80 pb-1.5"
                    >
                      <div>
                        <div className="text-neutral-200 font-medium">{p.partName}</div>
                        <div className="text-[11px] text-neutral-500 font-mono">
                          {p.quantity}x @ ${p.unitCost} ea
                        </div>
                      </div>
                      <span className="font-mono text-neutral-300 tabular-nums">
                        ${(p.quantity * p.unitCost).toFixed(2)}
                      </span>
                    </div>
                  ))
                )}
              </div>

              {/* Allocate spare part form */}
              <form onSubmit={handleAllocatePart} className="pt-2 border-t border-neutral-800 space-y-2">
                <div className="text-[11px] text-neutral-400 font-medium">Allocate from Inventory:</div>
                <div className="flex gap-2">
                  <select
                    value={selectedPartId}
                    onChange={(e) => setSelectedPartId(e.target.value)}
                    className="flex-1 bg-neutral-900 border border-neutral-800 rounded px-2 py-1 text-xs text-neutral-300 focus:outline-none focus:border-amber-500"
                  >
                    <option value="">Select Spare Part...</option>
                    {facilityParts.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.name} ({p.quantityInStock} in stock - ${p.unitCost})
                      </option>
                    ))}
                  </select>
                  <input
                    type="number"
                    min="1"
                    value={partQty}
                    onChange={(e) => setPartQty(parseInt(e.target.value) || 1)}
                    className="w-14 bg-neutral-900 border border-neutral-800 rounded px-2 py-1 text-xs text-neutral-300 text-center font-mono"
                  />
                  <button
                    type="submit"
                    className="px-2.5 py-1 bg-amber-500 hover:bg-amber-400 text-neutral-950 font-semibold text-xs rounded transition-colors"
                  >
                    Add
                  </button>
                </div>
              </form>
            </div>

            {/* Labor Hours Logged */}
            <div className="rounded-lg border border-neutral-800 bg-neutral-950 p-4 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-neutral-200">
                  <Clock className="h-4 w-4 text-amber-400" />
                  <span>Labor Time Tracking</span>
                </div>
                <span className="font-mono text-xs text-amber-400 tabular-nums font-bold">
                  {wo.laborHoursLogged.toFixed(1)} hrs (${(wo.laborHoursLogged * laborRateEstimate).toFixed(2)})
                </span>
              </div>

              <div className="text-xs text-neutral-400">
                Primary technician logged time: {wo.laborHoursLogged} hours. Standard billing rate applies at ${laborRateEstimate}/hr.
              </div>

              <form onSubmit={handleAddLabor} className="pt-2 border-t border-neutral-800 space-y-2">
                <div className="text-[11px] text-neutral-400 font-medium">Log Labor Increment:</div>
                <div className="flex gap-2">
                  <input
                    type="number"
                    step="0.5"
                    min="0.5"
                    placeholder="e.g. 1.5"
                    value={additionalLaborHours}
                    onChange={(e) => setAdditionalLaborHours(e.target.value)}
                    className="flex-1 bg-neutral-900 border border-neutral-800 rounded px-2.5 py-1 text-xs text-neutral-300 font-mono focus:outline-none focus:border-amber-500"
                  />
                  <button
                    type="submit"
                    className="px-3 py-1 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-medium rounded transition-colors"
                  >
                    + Log Hours
                  </button>
                </div>
              </form>

              {wo.failureCode && (
                <div className="pt-2 border-t border-neutral-800 text-xs">
                  <span className="text-neutral-500 block mb-0.5">Failure Diagnostics Code:</span>
                  <span className="text-amber-300 font-medium">{wo.failureCode}</span>
                </div>
              )}
            </div>
          </div>

          {/* Digital Sign-off Verification Section */}
          <div className="rounded-lg border border-neutral-800 bg-neutral-950 p-4 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-neutral-200">
                <ShieldCheck className="h-4 w-4 text-emerald-400" />
                <span>Compliance & Manager Sign-Off</span>
              </div>
              {wo.signedOffBy ? (
                <span className="text-xs text-emerald-400 font-semibold font-mono flex items-center gap-1">
                  <CheckCircle2 className="h-3.5 w-3.5" />
                  <span>Verified & Sealed</span>
                </span>
              ) : (
                <span className="text-xs text-amber-400 font-mono">Pending Signature</span>
              )}
            </div>

            {wo.signedOffBy ? (
              <div className="rounded border border-emerald-900/40 bg-emerald-950/20 p-3 text-xs space-y-1">
                <div className="text-emerald-300 font-semibold">
                  Signed off by: {wo.signedOffBy}
                </div>
                <div className="text-neutral-400 text-[11px] font-mono">
                  Timestamp: {new Date(wo.signatureTimestamp || '').toLocaleString()}
                </div>
                <div className="text-neutral-500 text-[11px]">
                  Archived to {currentFacility.complianceBody} Audit Ledger
                </div>
              </div>
            ) : isSigning ? (
              <form onSubmit={handleSignOffSubmit} className="space-y-3 pt-2">
                <div className="text-xs text-neutral-300">
                  By applying your electronic signature, you certify all corrective tasks have been validated in accordance with {currentFacility.complianceStandard}.
                </div>
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="Enter Supervisor / Inspector Name..."
                    value={signerName}
                    onChange={(e) => setSignerName(e.target.value)}
                    className="flex-1 bg-neutral-900 border border-neutral-800 rounded px-3 py-1.5 text-xs text-neutral-200 focus:outline-none focus:border-amber-500"
                    autoFocus
                  />
                  <button
                    type="submit"
                    className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs rounded transition-colors whitespace-nowrap"
                  >
                    Confirm Sign-Off
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsSigning(false)}
                    className="px-3 py-1.5 bg-neutral-800 text-neutral-400 text-xs rounded hover:text-white"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            ) : (
              <div className="flex items-center justify-between text-xs text-neutral-400 pt-1">
                <span>Total Work Order Financial Impact: <strong className="font-mono text-white tabular-nums">${totalEstimatedCost.toFixed(2)}</strong></span>
                <button
                  onClick={() => setIsSigning(true)}
                  className="px-3 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 font-medium text-xs rounded transition-colors"
                >
                  Capture Electronic Signature
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Modal Bottom Footer */}
        <div className="border-t border-neutral-800 px-6 py-3 bg-neutral-950 flex items-center justify-between text-xs text-neutral-500">
          <div className="font-mono">
            Created: {new Date(wo.createdAt).toLocaleDateString()} · Due: {new Date(wo.dueDate).toLocaleDateString()}
          </div>
          <button
            onClick={() => setSelectedWorkOrderId(null)}
            className="px-4 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-white rounded font-medium transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
