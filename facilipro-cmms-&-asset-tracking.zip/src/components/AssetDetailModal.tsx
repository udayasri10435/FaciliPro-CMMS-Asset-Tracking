import React, { useState } from 'react';
import { useCMMS } from '../context/CMMSContext';
import { AssetStatus } from '../types/cmms';
import {
  X,
  QrCode,
  MapPin,
  Wrench,
  Activity,
  Calendar,
  ShieldCheck,
  Printer,
  Download,
  AlertTriangle,
  Clock,
  ArrowRight,
  ExternalLink,
} from 'lucide-react';

export const AssetDetailModal: React.FC = () => {
  const {
    selectedAssetId,
    setSelectedAssetId,
    assets,
    updateAssetStatus,
    workOrders,
    setSelectedWorkOrderId,
    setIsCreateWoOpen,
    setIsFloorPlanOpen,
    showToast,
  } = useCMMS();

  const [showQrPrintView, setShowQrPrintView] = useState(false);

  if (!selectedAssetId) return null;

  const asset = assets.find((a) => a.id === selectedAssetId);
  if (!asset) return null;

  const assetWorkOrders = workOrders.filter((w) => w.assetId === asset.id);

  const getStatusColor = (status: AssetStatus) => {
    switch (status) {
      case 'operational':
        return 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20';
      case 'needs_service':
        return 'text-amber-400 bg-amber-500/10 border-amber-500/20';
      case 'under_repair':
        return 'text-blue-400 bg-blue-500/10 border-blue-500/20';
      case 'critical_down':
        return 'text-rose-400 bg-rose-500/10 border-rose-500/20';
    }
  };

  const handlePrintTag = () => {
    showToast(`Print job sent: Field QR Tag for ${asset.assetTag}`);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-4xl rounded-xl border border-neutral-800 bg-neutral-900 shadow-2xl overflow-hidden my-6 max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-neutral-800 px-6 py-4 bg-neutral-950">
          <div className="flex items-center gap-3">
            <span className="font-mono text-sm font-bold text-amber-400">
              {asset.assetTag}
            </span>
            <span aria-hidden="true" className="text-neutral-600">·</span>
            <span className="text-xs text-neutral-400">{asset.category}</span>
            <span aria-hidden="true" className="text-neutral-600">·</span>
            <span className="text-xs font-semibold text-neutral-300">{asset.criticality}</span>
          </div>

          <button
            onClick={() => setSelectedAssetId(null)}
            className="rounded p-1 text-neutral-400 hover:bg-neutral-800 hover:text-white transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Action & Status Toolbar */}
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-neutral-800 px-6 py-2.5 bg-neutral-950/70">
          <div className="flex items-center gap-3">
            <span className="text-xs text-neutral-400">Operational State:</span>
            <select
              value={asset.status}
              onChange={(e) => updateAssetStatus(asset.id, e.target.value as AssetStatus)}
              className="bg-neutral-900 border border-neutral-800 rounded px-2.5 py-1 text-xs text-neutral-200 capitalize focus:outline-none focus:border-amber-500"
            >
              <option value="operational">Operational</option>
              <option value="needs_service">Needs Service</option>
              <option value="under_repair">Under Repair</option>
              <option value="critical_down">Critical Down</option>
            </select>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                setSelectedAssetId(null);
                setIsFloorPlanOpen(true);
              }}
              className="flex items-center gap-1.5 px-3 py-1 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 rounded text-xs font-medium transition-colors"
            >
              <MapPin className="h-3.5 w-3.5 text-blue-400" />
              <span>Locate on Floor Map</span>
            </button>

            <button
              onClick={() => setShowQrPrintView(!showQrPrintView)}
              className="flex items-center gap-1.5 px-3 py-1 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 rounded text-xs font-medium transition-colors"
            >
              <QrCode className="h-3.5 w-3.5 text-amber-400" />
              <span>{showQrPrintView ? 'Hide Tag' : 'Machine QR Tag'}</span>
            </button>

            <button
              onClick={() => {
                setIsCreateWoOpen(true);
              }}
              className="flex items-center gap-1.5 px-3 py-1 bg-amber-500 hover:bg-amber-400 text-neutral-950 rounded text-xs font-semibold transition-colors"
            >
              <Wrench className="h-3.5 w-3.5" />
              <span>+ Log Work Order</span>
            </button>
          </div>
        </div>

        {/* Modal Body (Scrollable) */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 text-xs">
          {/* Machine Tag & QR Code Preview if active */}
          {showQrPrintView && (
            <div className="rounded-lg border border-amber-500/30 bg-neutral-950 p-6 flex flex-col sm:flex-row items-center justify-between gap-6 shadow-inner">
              <div className="flex items-center gap-6">
                {/* SVG QR Code Simulation */}
                <div className="h-32 w-32 bg-white p-2 rounded flex flex-col justify-between items-center shadow">
                  <div className="w-full h-full flex flex-col justify-between">
                    <div className="flex justify-between">
                      <div className="w-6 h-6 border-4 border-black" />
                      <div className="w-4 h-4 bg-black" />
                      <div className="w-6 h-6 border-4 border-black" />
                    </div>
                    <div className="flex justify-center items-center py-1">
                      <div className="grid grid-cols-4 gap-1">
                        <div className="w-2 h-2 bg-black" />
                        <div className="w-2 h-2 bg-black" />
                        <div className="w-2 h-2 bg-white border border-black" />
                        <div className="w-2 h-2 bg-black" />
                      </div>
                    </div>
                    <div className="flex justify-between items-end">
                      <div className="w-6 h-6 border-4 border-black" />
                      <div className="text-[9px] font-mono font-bold text-black">FP-QR</div>
                      <div className="w-4 h-4 bg-black" />
                    </div>
                  </div>
                </div>

                <div className="space-y-1">
                  <div className="text-[11px] font-mono text-amber-400 font-bold">
                    FIELD EQUIPMENT IDENTIFICATION TAG
                  </div>
                  <div className="text-base font-bold text-white">{asset.name}</div>
                  <div className="font-mono text-neutral-300">TAG: {asset.assetTag}</div>
                  <div className="font-mono text-neutral-400">SERIAL: {asset.serialNumber}</div>
                  <div className="text-[11px] text-neutral-500">Scan via FaciliPro Mobile app for immediate equipment dossier</div>
                </div>
              </div>

              <div className="flex flex-col gap-2 shrink-0">
                <button
                  onClick={handlePrintTag}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-white rounded font-medium transition-colors"
                >
                  <Printer className="h-3.5 w-3.5" />
                  <span>Print Industrial Label</span>
                </button>
              </div>
            </div>
          )}

          {/* Title & Location Header */}
          <div className="space-y-1">
            <h2 className="text-xl font-bold text-white">{asset.name}</h2>
            <div className="flex items-center gap-2 text-neutral-400">
              <MapPin className="h-3.5 w-3.5 text-neutral-500" />
              <span>
                {asset.location.building} · {asset.location.floor} · {asset.location.room} ({asset.location.zone})
              </span>
            </div>
          </div>

          {/* Reliability & Telemetry Strip */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="rounded-lg border border-neutral-800 bg-neutral-950 p-3">
              <span className="text-[11px] text-neutral-500 block uppercase">Health Score</span>
              <span className="text-2xl font-bold font-mono text-emerald-400 tabular-nums">
                {asset.healthScore}%
              </span>
              <div className="text-[10px] text-neutral-500 mt-0.5">Continuous diagnostics</div>
            </div>

            <div className="rounded-lg border border-neutral-800 bg-neutral-950 p-3">
              <span className="text-[11px] text-neutral-500 block uppercase">Uptime Reliability</span>
              <span className="text-2xl font-bold font-mono text-white tabular-nums">
                {asset.uptimePercentage}%
              </span>
              <div className="text-[10px] text-neutral-500 mt-0.5">365-day rolling</div>
            </div>

            <div className="rounded-lg border border-neutral-800 bg-neutral-950 p-3">
              <span className="text-[11px] text-neutral-500 block uppercase">MTBF (Failure Interval)</span>
              <span className="text-2xl font-bold font-mono text-neutral-200 tabular-nums">
                {asset.mtbfHours.toLocaleString()}h
              </span>
              <div className="text-[10px] text-neutral-500 mt-0.5">Mean Time Between Failures</div>
            </div>

            <div className="rounded-lg border border-neutral-800 bg-neutral-950 p-3">
              <span className="text-[11px] text-neutral-500 block uppercase">MTTR (Repair Time)</span>
              <span className="text-2xl font-bold font-mono text-amber-400 tabular-nums">
                {asset.mttrHours}h
              </span>
              <div className="text-[10px] text-neutral-500 mt-0.5">Mean Time To Repair</div>
            </div>
          </div>

          {/* Technical Specifications Table */}
          <div className="rounded-lg border border-neutral-800 bg-neutral-950 p-4 space-y-3">
            <div className="text-xs font-semibold uppercase tracking-wider text-neutral-200">
              Technical Specifications & Operating Parameters
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-2 border-t border-neutral-800/80 pt-3">
              <div className="flex justify-between py-1 border-b border-neutral-900">
                <span className="text-neutral-500">Manufacturer</span>
                <span className="text-neutral-200 font-medium">{asset.manufacturer}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-neutral-900">
                <span className="text-neutral-500">Model Number</span>
                <span className="text-neutral-200 font-mono">{asset.model}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-neutral-900">
                <span className="text-neutral-500">Serial Number</span>
                <span className="text-neutral-200 font-mono">{asset.serialNumber}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-neutral-900">
                <span className="text-neutral-500">Commission Date</span>
                <span className="text-neutral-200 font-mono">{asset.installDate}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-neutral-900">
                <span className="text-neutral-500">Warranty Status</span>
                <span className="text-emerald-400 font-medium font-mono">Valid until {asset.warrantyExpiry}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-neutral-900">
                <span className="text-neutral-500">Total Run Hours</span>
                <span className="text-neutral-200 font-mono tabular-nums">{asset.runtimeHours.toLocaleString()} hrs</span>
              </div>

              {Object.entries(asset.specs).map(([key, val]) => (
                <div key={key} className="flex justify-between py-1 border-b border-neutral-900">
                  <span className="text-neutral-500">{key}</span>
                  <span className="text-neutral-200 font-mono">{val}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Maintenance History & Linked Work Orders */}
          <div className="rounded-lg border border-neutral-800 bg-neutral-950 p-4 space-y-3">
            <div className="flex items-center justify-between">
              <div className="text-xs font-semibold uppercase tracking-wider text-neutral-200">
                Maintenance Ledger ({assetWorkOrders.length} Records)
              </div>
              <span className="text-[11px] text-neutral-500">Last Serviced: {asset.lastServiceDate}</span>
            </div>

            <div className="space-y-2 border-t border-neutral-800/80 pt-3">
              {assetWorkOrders.length === 0 ? (
                <div className="text-neutral-500 py-3 text-center italic">
                  No previous corrective tickets for this machine.
                </div>
              ) : (
                assetWorkOrders.map((wo) => (
                  <div
                    key={wo.id}
                    onClick={() => {
                      setSelectedAssetId(null);
                      setSelectedWorkOrderId(wo.id);
                    }}
                    className="flex items-center justify-between p-2.5 rounded bg-neutral-900/60 border border-neutral-800 hover:border-neutral-700 cursor-pointer transition-colors"
                  >
                    <div>
                      <div className="flex items-center gap-2 font-mono text-[11px]">
                        <span className="text-amber-400 font-bold">{wo.woNumber}</span>
                        <span aria-hidden="true" className="text-neutral-600">·</span>
                        <span className="text-neutral-300 font-medium capitalize">{wo.type}</span>
                        <span aria-hidden="true" className="text-neutral-600">·</span>
                        <span className="text-neutral-500">{new Date(wo.createdAt).toLocaleDateString()}</span>
                      </div>
                      <div className="text-white font-medium mt-0.5">{wo.title}</div>
                    </div>

                    <div className="text-right">
                      <span className="text-[10px] uppercase font-semibold text-neutral-300 bg-neutral-800 px-2 py-0.5 rounded">
                        {wo.status.replace('_', ' ')}
                      </span>
                      <div className="text-[10px] text-neutral-500 mt-1">
                        {wo.assignedTechnician.name}
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="border-t border-neutral-800 px-6 py-3 bg-neutral-950 flex items-center justify-end">
          <button
            onClick={() => setSelectedAssetId(null)}
            className="px-4 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-white rounded font-medium transition-colors"
          >
            Close Dossier
          </button>
        </div>
      </div>
    </div>
  );
};
