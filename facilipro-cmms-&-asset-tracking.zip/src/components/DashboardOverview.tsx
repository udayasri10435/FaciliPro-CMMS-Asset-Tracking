import React from 'react';
import { useCMMS } from '../context/CMMSContext';
import {
  AlertTriangle,
  CheckCircle2,
  Clock,
  QrCode,
  MapPin,
  Calendar,
  Wrench,
  ShieldCheck,
  TrendingUp,
  ArrowUpRight,
  Sparkles,
  Zap,
  Box,
} from 'lucide-react';

interface DashboardOverviewProps {
  onNavigateToTab: (tab: string) => void;
}

export const DashboardOverview: React.FC<DashboardOverviewProps> = ({ onNavigateToTab }) => {
  const {
    currentFacility,
    facilities,
    setCurrentFacilityId,
    workOrders,
    assets,
    preventiveSchedules,
    spareParts,
    setSelectedWorkOrderId,
    setSelectedAssetId,
    setIsQrScannerOpen,
    setIsFloorPlanOpen,
    setIsCreateWoOpen,
    setIsComplianceReportOpen,
    generateWorkOrderFromPM,
  } = useCMMS();

  // Filter items by current facility
  const facilityWorkOrders = workOrders.filter((wo) => wo.facilityId === currentFacility.id);
  const facilityAssets = assets.filter((a) => a.facilityId === currentFacility.id);
  const facilityPMs = preventiveSchedules.filter((pm) => pm.facilityId === currentFacility.id);
  const lowStockParts = spareParts.filter(
    (p) => p.facilityId === currentFacility.id && p.quantityInStock <= p.minReorderPoint
  );

  const openWOs = facilityWorkOrders.filter((w) => w.status !== 'completed' && w.status !== 'verified');
  const emergencyWOs = openWOs.filter((w) => w.priority === 'emergency' || w.priority === 'urgent');

  // Compute stats
  const averageUptime =
    facilityAssets.length > 0
      ? (
          facilityAssets.reduce((acc, a) => acc + a.uptimePercentage, 0) / facilityAssets.length
        ).toFixed(2)
      : '99.50';

  const averageMttr =
    facilityAssets.length > 0
      ? (facilityAssets.reduce((acc, a) => acc + a.mttrHours, 0) / facilityAssets.length).toFixed(1)
      : '2.1';

  return (
    <div className="space-y-6 pb-12">
      {/* Industry Facility Switcher & Context Banner */}
      <section className="rounded-lg border border-neutral-800 bg-neutral-900/60 p-5 backdrop-blur-sm">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2 text-xs text-neutral-400">
              <span className="font-semibold text-amber-400">{currentFacility.industryLabel}</span>
              <span aria-hidden="true">·</span>
              <span>{currentFacility.squareFeet.toLocaleString()} sq ft</span>
              <span aria-hidden="true">·</span>
              <span>{currentFacility.buildingsCount} Buildings</span>
              <span aria-hidden="true">·</span>
              <span>Standard: {currentFacility.complianceStandard}</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white">
              {currentFacility.name}
            </h1>
            <p className="text-xs sm:text-sm text-neutral-400">
              {currentFacility.address}
            </p>
          </div>

          {/* Quick vertical switch buttons for Sales demonstration */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2 pt-2 lg:pt-0">
            <span className="text-[11px] font-medium text-neutral-500 uppercase tracking-wider">
              Switch Industry:
            </span>
            <div className="flex flex-wrap items-center gap-1.5 p-1 bg-neutral-950 rounded-md border border-neutral-800">
              {facilities.map((fac) => (
                <button
                  key={fac.id}
                  onClick={() => setCurrentFacilityId(fac.id)}
                  className={`px-2.5 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap ${
                    fac.id === currentFacility.id
                      ? 'bg-amber-500 text-neutral-950 font-semibold'
                      : 'text-neutral-400 hover:text-neutral-200'
                  }`}
                >
                  {fac.industry === 'hospital' && '🏥 Hospital'}
                  {fac.industry === 'school' && '🏫 School'}
                  {fac.industry === 'office' && '🏢 Office'}
                  {fac.industry === 'warehouse' && '📦 Warehouse'}
                </button>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* KPI Metric Strip */}
      <section className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="rounded-lg border border-neutral-800 bg-neutral-900/80 p-3.5 flex flex-col justify-between">
          <div className="text-[11px] font-medium text-neutral-400">Open Work Orders</div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-2xl font-bold text-white font-mono tabular-nums">
              {openWOs.length}
            </span>
            {emergencyWOs.length > 0 && (
              <span className="text-[11px] font-semibold text-rose-400 font-mono">
                {emergencyWOs.length} urgent
              </span>
            )}
          </div>
          <div className="text-[10px] text-neutral-500 mt-1">
            {openWOs.filter((w) => w.status === 'in_progress').length} active in field
          </div>
        </div>

        <div className="rounded-lg border border-neutral-800 bg-neutral-900/80 p-3.5 flex flex-col justify-between">
          <div className="text-[11px] font-medium text-neutral-400">PM Compliance Rate</div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-2xl font-bold text-emerald-400 font-mono tabular-nums">
              {currentFacility.pmComplianceRate}%
            </span>
            <ShieldCheck className="h-4 w-4 text-emerald-500" />
          </div>
          <div className="text-[10px] text-neutral-500 mt-1">Audit compliant</div>
        </div>

        <div className="rounded-lg border border-neutral-800 bg-neutral-900/80 p-3.5 flex flex-col justify-between">
          <div className="text-[11px] font-medium text-neutral-400">Equipment Uptime</div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-2xl font-bold text-white font-mono tabular-nums">
              {averageUptime}%
            </span>
            <span className="text-[11px] font-medium text-emerald-400">Nominal</span>
          </div>
          <div className="text-[10px] text-neutral-500 mt-1">
            {facilityAssets.length} tracked machines
          </div>
        </div>

        <div className="rounded-lg border border-neutral-800 bg-neutral-900/80 p-3.5 flex flex-col justify-between">
          <div className="text-[11px] font-medium text-neutral-400">Mean Time to Repair</div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-2xl font-bold text-amber-400 font-mono tabular-nums">
              {averageMttr}h
            </span>
            <Clock className="h-4 w-4 text-amber-500" />
          </div>
          <div className="text-[10px] text-neutral-500 mt-1">Target &lt; 3.0 hrs</div>
        </div>

        <div className="rounded-lg border border-neutral-800 bg-neutral-900/80 p-3.5 flex flex-col justify-between">
          <div className="text-[11px] font-medium text-neutral-400">Preventive Due (7d)</div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-2xl font-bold text-white font-mono tabular-nums">
              {facilityPMs.length}
            </span>
            <Calendar className="h-4 w-4 text-neutral-400" />
          </div>
          <div className="text-[10px] text-neutral-500 mt-1">Scheduled cycles</div>
        </div>

        <div className="rounded-lg border border-neutral-800 bg-neutral-900/80 p-3.5 flex flex-col justify-between">
          <div className="text-[11px] font-medium text-neutral-400">Low Stock Spares</div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className={`text-2xl font-bold font-mono tabular-nums ${lowStockParts.length > 0 ? 'text-amber-400' : 'text-neutral-300'}`}>
              {lowStockParts.length}
            </span>
            <Box className="h-4 w-4 text-neutral-400" />
          </div>
          <div className="text-[10px] text-neutral-500 mt-1">
            {lowStockParts.length > 0 ? 'Below reorder point' : 'All levels nominal'}
          </div>
        </div>
      </section>

      {/* Quick Action Dock */}
      <section className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <button
          onClick={() => setIsQrScannerOpen(true)}
          className="flex items-center gap-3 rounded-lg border border-neutral-800 bg-neutral-900/70 p-3 text-left hover:border-amber-500/50 hover:bg-neutral-800/80 transition-all group"
        >
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-md bg-amber-500/10 text-amber-400 group-hover:bg-amber-500 group-hover:text-neutral-950 transition-colors">
            <QrCode className="h-5 w-5" />
          </div>
          <div>
            <div className="text-xs font-semibold text-white">Scan Machine QR</div>
            <div className="text-[11px] text-neutral-400">Instant field tag lookup</div>
          </div>
        </button>

        <button
          onClick={() => setIsFloorPlanOpen(true)}
          className="flex items-center gap-3 rounded-lg border border-neutral-800 bg-neutral-900/70 p-3 text-left hover:border-amber-500/50 hover:bg-neutral-800/80 transition-all group"
        >
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-md bg-blue-500/10 text-blue-400 group-hover:bg-blue-500 group-hover:text-neutral-950 transition-colors">
            <MapPin className="h-5 w-5" />
          </div>
          <div>
            <div className="text-xs font-semibold text-white">Facility Floor Map</div>
            <div className="text-[11px] text-neutral-400">Live equipment pin map</div>
          </div>
        </button>

        <button
          onClick={() => setIsCreateWoOpen(true)}
          className="flex items-center gap-3 rounded-lg border border-neutral-800 bg-neutral-900/70 p-3 text-left hover:border-amber-500/50 hover:bg-neutral-800/80 transition-all group"
        >
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-md bg-emerald-500/10 text-emerald-400 group-hover:bg-emerald-500 group-hover:text-neutral-950 transition-colors">
            <Wrench className="h-5 w-5" />
          </div>
          <div>
            <div className="text-xs font-semibold text-white">Log Work Order</div>
            <div className="text-[11px] text-neutral-400">Corrective / emergency</div>
          </div>
        </button>

        <button
          onClick={() => setIsComplianceReportOpen(true)}
          className="flex items-center gap-3 rounded-lg border border-neutral-800 bg-neutral-900/70 p-3 text-left hover:border-amber-500/50 hover:bg-neutral-800/80 transition-all group"
        >
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-md bg-purple-500/10 text-purple-400 group-hover:bg-purple-500 group-hover:text-neutral-950 transition-colors">
            <ShieldCheck className="h-5 w-5" />
          </div>
          <div>
            <div className="text-xs font-semibold text-white">Compliance Dossier</div>
            <div className="text-[11px] text-neutral-400">Audit-ready documentation</div>
          </div>
        </button>
      </section>

      {/* Main Grid: Critical Triage & Preventive Maintenance Cadence */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Col (8 cols): Critical & In-Progress Work Orders */}
        <div className="lg:col-span-7 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-semibold text-white uppercase tracking-wider">
                Work Orders Requiring Action
              </h2>
              <span className="text-xs text-neutral-500 font-mono">({openWOs.length})</span>
            </div>
            <button
              onClick={() => onNavigateToTab('work-orders')}
              className="text-xs font-medium text-amber-400 hover:text-amber-300 flex items-center gap-1"
            >
              <span>View All</span>
              <ArrowUpRight className="h-3 w-3" />
            </button>
          </div>

          <div className="space-y-2.5">
            {openWOs.length === 0 ? (
              <div className="rounded-lg border border-neutral-800 bg-neutral-900/40 p-8 text-center">
                <CheckCircle2 className="h-8 w-8 text-emerald-400 mx-auto mb-2" />
                <p className="text-sm font-medium text-neutral-200">All work orders nominal</p>
                <p className="text-xs text-neutral-500 mt-1">
                  No pending corrective or emergency tickets for this facility.
                </p>
              </div>
            ) : (
              openWOs.map((wo) => {
                const isEmergency = wo.priority === 'emergency';
                const isUrgent = wo.priority === 'urgent';

                return (
                  <div
                    key={wo.id}
                    onClick={() => setSelectedWorkOrderId(wo.id)}
                    className="rounded-lg border border-neutral-800 bg-neutral-900/70 p-4 hover:border-neutral-700 transition-all cursor-pointer group"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2 text-xs text-neutral-400 font-mono">
                          <span className="text-amber-400 font-semibold">{wo.woNumber}</span>
                          <span aria-hidden="true">·</span>
                          <span className="text-neutral-300">{wo.assetTag}</span>
                          <span aria-hidden="true">·</span>
                          <span className={`capitalize font-semibold ${
                            isEmergency ? 'text-rose-400' : isUrgent ? 'text-amber-400' : 'text-neutral-400'
                          }`}>
                            {wo.priority}
                          </span>
                        </div>
                        <h3 className="text-sm font-semibold text-white group-hover:text-amber-300 transition-colors">
                          {wo.title}
                        </h3>
                        <p className="text-xs text-neutral-400 line-clamp-1">
                          {wo.description}
                        </p>
                      </div>

                      <div className="text-right shrink-0">
                        <span className={`inline-block px-2 py-0.5 text-[10px] font-semibold rounded uppercase tracking-wider ${
                          wo.status === 'in_progress'
                            ? 'bg-blue-500/10 text-blue-400 border border-blue-500/30'
                            : wo.status === 'waiting_parts'
                            ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                            : 'bg-neutral-800 text-neutral-300'
                        }`}>
                          {wo.status.replace('_', ' ')}
                        </span>
                        <div className="text-[11px] text-neutral-500 font-mono tabular-nums mt-1">
                          SLA: {wo.slaHoursRemaining}h left
                        </div>
                      </div>
                    </div>

                    <div className="mt-3 pt-3 border-t border-neutral-800/80 flex items-center justify-between text-xs text-neutral-400">
                      <div className="flex items-center gap-2">
                        <span className="text-neutral-500">Tech:</span>
                        <span className="text-neutral-300">{wo.assignedTechnician.name}</span>
                      </div>
                      <div className="flex items-center gap-3 font-mono text-[11px]">
                        <span>{wo.checklist.filter((c) => c.completed).length}/{wo.checklist.length} checklist</span>
                        <span aria-hidden="true">·</span>
                        <span>{wo.laborHoursLogged}h logged</span>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Right Col (5 cols): Scheduled Preventive Audits & Equipment Health */}
        <div className="lg:col-span-5 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-semibold text-white uppercase tracking-wider">
              Preventive Maintenance (PM)
            </h2>
            <button
              onClick={() => onNavigateToTab('preventive')}
              className="text-xs font-medium text-amber-400 hover:text-amber-300 flex items-center gap-1"
            >
              <span>Manage PMs</span>
              <ArrowUpRight className="h-3 w-3" />
            </button>
          </div>

          <div className="space-y-2.5">
            {facilityPMs.map((pm) => (
              <div
                key={pm.id}
                className="rounded-lg border border-neutral-800 bg-neutral-900/70 p-3.5 space-y-2"
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <div className="flex items-center gap-2 text-xs text-neutral-400">
                      <span className="font-mono text-amber-400 text-[11px]">{pm.pmCode}</span>
                      <span aria-hidden="true">·</span>
                      <span className="text-neutral-300 font-medium">{pm.frequency}</span>
                    </div>
                    <h4 className="text-xs font-semibold text-white mt-0.5">
                      {pm.title}
                    </h4>
                  </div>
                  <button
                    onClick={() => generateWorkOrderFromPM(pm.id)}
                    className="shrink-0 px-2 py-1 bg-amber-500/10 hover:bg-amber-500 hover:text-neutral-950 text-amber-400 text-[11px] font-semibold rounded border border-amber-500/20 transition-all"
                    title="Generate ready-to-dispatch Work Order"
                  >
                    + Trigger WO
                  </button>
                </div>

                <div className="text-[11px] text-neutral-400">
                  <span className="text-neutral-500">Asset:</span> {pm.assetName}
                </div>

                <div className="flex items-center justify-between text-[11px] text-neutral-500 border-t border-neutral-800/80 pt-2">
                  <span>Standard: {pm.complianceStandard.split('/')[0]}</span>
                  <span className="font-mono text-neutral-400">Due: {pm.nextDueDate}</span>
                </div>
              </div>
            ))}
          </div>

          {/* Low Stock Spares Warning Box if any */}
          {lowStockParts.length > 0 && (
            <div className="rounded-lg border border-amber-900/50 bg-amber-950/20 p-4 space-y-2">
              <div className="flex items-center gap-2 text-amber-400 text-xs font-semibold">
                <AlertTriangle className="h-4 w-4 shrink-0" />
                <span>Spare Parts Requiring Reorder</span>
              </div>
              <p className="text-xs text-neutral-400">
                {lowStockParts.length} critical spare parts are below minimum safety stock levels:
              </p>
              <div className="space-y-1.5 pt-1">
                {lowStockParts.map((part) => (
                  <div
                    key={part.id}
                    className="flex items-center justify-between text-xs border-b border-amber-900/30 pb-1 last:border-0"
                  >
                    <span className="text-neutral-300 truncate max-w-[200px]">{part.name}</span>
                    <span className="font-mono text-amber-400 font-semibold">
                      {part.quantityInStock} in stock (Min {part.minReorderPoint})
                    </span>
                  </div>
                ))}
              </div>
              <button
                onClick={() => onNavigateToTab('parts')}
                className="w-full text-center py-1.5 text-xs text-amber-400 font-semibold hover:underline"
              >
                Open Spare Parts Catalog →
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
