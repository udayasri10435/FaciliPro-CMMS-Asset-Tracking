import React, { useState } from 'react';
import { useCMMS } from '../context/CMMSContext';
import { WorkOrder, WorkOrderStatus, WorkOrderPriority, WorkOrderType } from '../types/cmms';
import {
  Search,
  Filter,
  Plus,
  LayoutGrid,
  List,
  Clock,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  User,
  Wrench,
  FileCheck,
} from 'lucide-react';

export const WorkOrdersView: React.FC = () => {
  const {
    workOrders,
    currentFacility,
    setSelectedWorkOrderId,
    setIsCreateWoOpen,
    updateWorkOrderStatus,
  } = useCMMS();

  const [viewMode, setViewMode] = useState<'kanban' | 'table'>('kanban');
  const [searchQuery, setSearchQuery] = useState('');
  const [priorityFilter, setPriorityFilter] = useState<string>('all');
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  // Filter for current facility
  const facilityOrders = workOrders.filter((wo) => wo.facilityId === currentFacility.id);

  // Apply search and filters
  const filteredOrders = facilityOrders.filter((wo) => {
    const matchesSearch =
      wo.woNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      wo.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      wo.assetName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      wo.assetTag.toLowerCase().includes(searchQuery.toLowerCase()) ||
      wo.assignedTechnician.name.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesPriority = priorityFilter === 'all' || wo.priority === priorityFilter;
    const matchesType = typeFilter === 'all' || wo.type === typeFilter;
    const matchesStatus = statusFilter === 'all' || wo.status === statusFilter;

    return matchesSearch && matchesPriority && matchesType && matchesStatus;
  });

  const columns: { status: WorkOrderStatus; label: string; countColor: string }[] = [
    { status: 'open', label: 'Open / Dispatched', countColor: 'text-neutral-400' },
    { status: 'in_progress', label: 'In Progress', countColor: 'text-blue-400' },
    { status: 'waiting_parts', label: 'Waiting Parts', countColor: 'text-amber-400' },
    { status: 'completed', label: 'Completed', countColor: 'text-emerald-400' },
    { status: 'verified', label: 'Signed Off / Closed', countColor: 'text-purple-400' },
  ];

  return (
    <div className="space-y-4 pb-12">
      {/* Top Controls Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 bg-neutral-900/60 p-4 rounded-lg border border-neutral-800">
        <div className="flex flex-1 items-center gap-3">
          {/* Search Box */}
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-neutral-500" />
            <input
              type="text"
              placeholder="Search WO#, asset, title, or technician..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-neutral-950 border border-neutral-800 rounded-md pl-9 pr-3 py-1.5 text-xs text-neutral-200 placeholder-neutral-500 focus:outline-none focus:border-amber-500"
            />
          </div>

          {/* Priority Filter */}
          <select
            value={priorityFilter}
            onChange={(e) => setPriorityFilter(e.target.value)}
            className="bg-neutral-950 border border-neutral-800 rounded-md px-2.5 py-1.5 text-xs text-neutral-300 focus:outline-none focus:border-amber-500"
          >
            <option value="all">All Priorities</option>
            <option value="emergency">Emergency</option>
            <option value="urgent">Urgent</option>
            <option value="routine">Routine</option>
            <option value="low">Low</option>
          </select>

          {/* Type Filter */}
          <select
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value)}
            className="hidden sm:block bg-neutral-950 border border-neutral-800 rounded-md px-2.5 py-1.5 text-xs text-neutral-300 focus:outline-none focus:border-amber-500"
          >
            <option value="all">All Types</option>
            <option value="corrective">Corrective</option>
            <option value="preventive">Preventive</option>
            <option value="inspection">Inspection</option>
            <option value="emergency">Emergency</option>
          </select>
        </div>

        {/* View Switcher & Create Action */}
        <div className="flex items-center gap-2">
          <div className="flex items-center bg-neutral-950 rounded-md border border-neutral-800 p-0.5">
            <button
              onClick={() => setViewMode('kanban')}
              className={`p-1.5 rounded text-xs transition-colors ${
                viewMode === 'kanban'
                  ? 'bg-neutral-800 text-white'
                  : 'text-neutral-400 hover:text-neutral-200'
              }`}
              title="Kanban Board View"
            >
              <LayoutGrid className="h-4 w-4" />
            </button>
            <button
              onClick={() => setViewMode('table')}
              className={`p-1.5 rounded text-xs transition-colors ${
                viewMode === 'table'
                  ? 'bg-neutral-800 text-white'
                  : 'text-neutral-400 hover:text-neutral-200'
              }`}
              title="Data Table View"
            >
              <List className="h-4 w-4" />
            </button>
          </div>

          <button
            onClick={() => setIsCreateWoOpen(true)}
            className="flex items-center gap-1.5 bg-amber-500 hover:bg-amber-400 text-neutral-950 font-semibold px-3 py-1.5 rounded-md text-xs transition-colors whitespace-nowrap"
          >
            <Plus className="h-4 w-4" />
            <span>Create WO</span>
          </button>
        </div>
      </div>

      {/* Kanban Board View */}
      {viewMode === 'kanban' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-3.5 items-start">
          {columns.map((col) => {
            const colOrders = filteredOrders.filter((wo) => wo.status === col.status);

            return (
              <div
                key={col.status}
                className="rounded-lg border border-neutral-800 bg-neutral-950/60 p-3 space-y-3 min-h-[500px]"
              >
                {/* Column Header */}
                <div className="flex items-center justify-between pb-2 border-b border-neutral-800">
                  <span className="text-xs font-semibold text-neutral-200 tracking-tight">
                    {col.label}
                  </span>
                  <span className={`text-xs font-mono font-bold ${col.countColor}`}>
                    {colOrders.length}
                  </span>
                </div>

                {/* Column Cards */}
                <div className="space-y-2.5">
                  {colOrders.length === 0 ? (
                    <div className="py-8 text-center text-xs text-neutral-600">
                      No work orders in this stage
                    </div>
                  ) : (
                    colOrders.map((wo) => {
                      const completedCount = wo.checklist.filter((c) => c.completed).length;
                      const isEmergency = wo.priority === 'emergency';
                      const isUrgent = wo.priority === 'urgent';

                      return (
                        <div
                          key={wo.id}
                          onClick={() => setSelectedWorkOrderId(wo.id)}
                          className="rounded-md border border-neutral-800 bg-neutral-900/90 p-3 hover:border-neutral-700 transition-all cursor-pointer space-y-2 group shadow-sm hover:shadow"
                        >
                          {/* Card Meta */}
                          <div className="flex items-center justify-between text-[11px] font-mono">
                            <span className="text-amber-400 font-semibold">{wo.woNumber}</span>
                            <span
                              className={`capitalize font-semibold ${
                                isEmergency
                                  ? 'text-rose-400'
                                  : isUrgent
                                  ? 'text-amber-400'
                                  : 'text-neutral-400'
                              }`}
                            >
                              {wo.priority}
                            </span>
                          </div>

                          {/* Card Title */}
                          <h4 className="text-xs font-semibold text-neutral-100 group-hover:text-amber-300 transition-colors line-clamp-2">
                            {wo.title}
                          </h4>

                          {/* Machine Tag & Location */}
                          <div className="text-[11px] text-neutral-400 truncate">
                            <span className="text-neutral-500 font-mono">{wo.assetTag}</span> · {wo.assetName}
                          </div>

                          {/* Checklist & Labor Progress */}
                          <div className="pt-2 border-t border-neutral-800/80 flex items-center justify-between text-[10px] text-neutral-500 font-mono">
                            <span>
                              {completedCount}/{wo.checklist.length} tasks
                            </span>
                            <span>{wo.assignedTechnician.name.split(' ')[0]}</span>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* Data Table Grid View */
        <div className="rounded-lg border border-neutral-800 bg-neutral-900/70 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-neutral-950/80 text-neutral-400 border-b border-neutral-800 text-[11px] font-semibold uppercase tracking-wider">
                <tr>
                  <th className="py-3 px-4">WO Number</th>
                  <th className="py-3 px-4">Priority</th>
                  <th className="py-3 px-4">Title & Description</th>
                  <th className="py-3 px-4">Asset & Zone</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4">Assignee</th>
                  <th className="py-3 px-4">Due / SLA</th>
                  <th className="py-3 px-4 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-800/60">
                {filteredOrders.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="py-8 text-center text-neutral-500">
                      No matching work orders found
                    </td>
                  </tr>
                ) : (
                  filteredOrders.map((wo) => {
                    const isEmergency = wo.priority === 'emergency';
                    const isUrgent = wo.priority === 'urgent';

                    return (
                      <tr
                        key={wo.id}
                        onClick={() => setSelectedWorkOrderId(wo.id)}
                        className="hover:bg-neutral-800/40 transition-colors cursor-pointer"
                      >
                        <td className="py-3 px-4 font-mono font-semibold text-amber-400 whitespace-nowrap">
                          {wo.woNumber}
                        </td>
                        <td className="py-3 px-4 whitespace-nowrap">
                          <span
                            className={`font-semibold capitalize text-[11px] ${
                              isEmergency
                                ? 'text-rose-400'
                                : isUrgent
                                ? 'text-amber-400'
                                : 'text-neutral-400'
                            }`}
                          >
                            {wo.priority}
                          </span>
                        </td>
                        <td className="py-3 px-4 max-w-xs">
                          <div className="font-medium text-white truncate">{wo.title}</div>
                          <div className="text-[11px] text-neutral-400 truncate">{wo.description}</div>
                        </td>
                        <td className="py-3 px-4 whitespace-nowrap">
                          <div className="font-mono text-neutral-300">{wo.assetTag}</div>
                          <div className="text-[11px] text-neutral-500">{wo.zone}</div>
                        </td>
                        <td className="py-3 px-4 whitespace-nowrap">
                          <span
                            className={`inline-block px-2 py-0.5 text-[10px] font-semibold rounded uppercase tracking-wider ${
                              wo.status === 'in_progress'
                                ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20'
                                : wo.status === 'waiting_parts'
                                ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                                : wo.status === 'completed'
                                ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                                : wo.status === 'verified'
                                ? 'bg-purple-500/10 text-purple-400 border border-purple-500/20'
                                : 'bg-neutral-800 text-neutral-300'
                            }`}
                          >
                            {wo.status.replace('_', ' ')}
                          </span>
                        </td>
                        <td className="py-3 px-4 whitespace-nowrap text-neutral-300">
                          {wo.assignedTechnician.name}
                        </td>
                        <td className="py-3 px-4 whitespace-nowrap font-mono tabular-nums text-neutral-400">
                          {wo.slaHoursRemaining}h remaining
                        </td>
                        <td className="py-3 px-4 text-right whitespace-nowrap">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setSelectedWorkOrderId(wo.id);
                            }}
                            className="text-amber-400 hover:text-amber-300 font-medium"
                          >
                            Inspect →
                          </button>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
