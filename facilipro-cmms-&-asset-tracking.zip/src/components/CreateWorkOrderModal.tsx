import React, { useState } from 'react';
import { useCMMS } from '../context/CMMSContext';
import { WorkOrderPriority, WorkOrderType } from '../types/cmms';
import { X, Wrench, AlertTriangle, Shield, Clock, User, CheckSquare } from 'lucide-react';

export const CreateWorkOrderModal: React.FC = () => {
  const {
    isCreateWoOpen,
    setIsCreateWoOpen,
    currentFacility,
    assets,
    technicians,
    createWorkOrder,
    setSelectedWorkOrderId,
  } = useCMMS();

  const facilityAssets = assets.filter((a) => a.facilityId === currentFacility.id);

  const [selectedAssetId, setSelectedAssetId] = useState(facilityAssets[0]?.id || '');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [priority, setPriority] = useState<WorkOrderPriority>('urgent');
  const [type, setType] = useState<WorkOrderType>('corrective');
  const [assignedTechId, setAssignedTechId] = useState(technicians[0]?.id || '');
  const [slaHours, setSlaHours] = useState('24');
  const [failureCode, setFailureCode] = useState('Mechanical Wear / Fatigue');

  if (!isCreateWoOpen) return null;

  const currentSelectedAsset = facilityAssets.find((a) => a.id === selectedAssetId) || facilityAssets[0];
  const assignedTech = technicians.find((t) => t.id === assignedTechId) || technicians[0];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    const dueDate = new Date(Date.now() + (Number(slaHours) || 24) * 3600 * 1000).toISOString();

    const created = createWorkOrder({
      facilityId: currentFacility.id,
      title: title.trim(),
      description: description.trim() || 'Urgent facility maintenance request reported by operator.',
      assetId: currentSelectedAsset.id,
      assetTag: currentSelectedAsset.assetTag,
      assetName: currentSelectedAsset.name,
      location: `${currentSelectedAsset.location.building}, ${currentSelectedAsset.location.floor}, ${currentSelectedAsset.location.room}`,
      zone: currentSelectedAsset.location.zone,
      priority,
      status: 'open',
      type,
      assignedTechnician: {
        id: assignedTech.id,
        name: assignedTech.name,
        role: assignedTech.role,
      },
      requestedBy: 'Facility Operator Dispatch',
      dueDate,
      slaHoursRemaining: Number(slaHours) || 24,
      laborHoursLogged: 0,
      partsUsed: [],
      checklist: [
        { id: 'c-1', task: `Perform LOTO and inspect ${currentSelectedAsset.name}`, completed: false },
        { id: 'c-2', task: `Diagnose ${failureCode} root cause`, completed: false },
        { id: 'c-3', task: 'Replace damaged component or calibrate sensor thresholds', completed: false },
        { id: 'c-4', task: 'Conduct functional load test and verify operating parameters', completed: false },
        { id: 'c-5', task: 'Clean work zone and document completion sign-off', completed: false },
      ],
      failureCode,
    });

    setIsCreateWoOpen(false);
    setSelectedWorkOrderId(created.id);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-2xl rounded-xl border border-neutral-800 bg-neutral-900 shadow-2xl overflow-hidden my-6">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-neutral-800 px-6 py-4 bg-neutral-950">
          <div className="flex items-center gap-2">
            <Wrench className="h-5 w-5 text-amber-400" />
            <h2 className="text-base font-semibold text-white">
              Log Maintenance Work Order
            </h2>
          </div>
          <button
            onClick={() => setIsCreateWoOpen(false)}
            className="rounded p-1 text-neutral-400 hover:bg-neutral-800 hover:text-white transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
          {/* Asset Selection */}
          <div className="space-y-1.5">
            <label className="text-neutral-400 font-medium">Select Target Asset / Machine</label>
            <select
              value={selectedAssetId}
              onChange={(e) => setSelectedAssetId(e.target.value)}
              className="w-full bg-neutral-950 border border-neutral-800 rounded-md px-3 py-2 text-neutral-200 focus:outline-none focus:border-amber-500 font-mono"
            >
              {facilityAssets.map((asset) => (
                <option key={asset.id} value={asset.id}>
                  [{asset.assetTag}] {asset.name} - {asset.location.room}
                </option>
              ))}
            </select>
            {currentSelectedAsset && (
              <div className="text-[11px] text-neutral-500 flex items-center gap-2 pt-0.5">
                <span>Location: {currentSelectedAsset.location.building} ({currentSelectedAsset.location.zone})</span>
                <span aria-hidden="true">·</span>
                <span className="font-mono">Health: {currentSelectedAsset.healthScore}%</span>
              </div>
            )}
          </div>

          {/* Title */}
          <div className="space-y-1.5">
            <label className="text-neutral-400 font-medium">Work Order Title / Incident Summary</label>
            <input
              type="text"
              required
              placeholder="e.g. Chiller Condenser Pump High Vibration Alarm"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full bg-neutral-950 border border-neutral-800 rounded-md px-3 py-2 text-neutral-200 placeholder-neutral-500 focus:outline-none focus:border-amber-500 text-xs"
            />
          </div>

          {/* Description */}
          <div className="space-y-1.5">
            <label className="text-neutral-400 font-medium">Symptom & Investigation Details</label>
            <textarea
              rows={3}
              placeholder="Describe observed operating defect, abnormal noise, leak, or inspection note..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full bg-neutral-950 border border-neutral-800 rounded-md px-3 py-2 text-neutral-200 placeholder-neutral-500 focus:outline-none focus:border-amber-500 text-xs"
            />
          </div>

          {/* Priority & Type Row */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-neutral-400 font-medium">Priority Level</label>
              <select
                value={priority}
                onChange={(e) => setPriority(e.target.value as WorkOrderPriority)}
                className="w-full bg-neutral-950 border border-neutral-800 rounded-md px-3 py-2 text-neutral-200 focus:outline-none focus:border-amber-500 capitalize"
              >
                <option value="emergency">🚨 Emergency (Immediate response)</option>
                <option value="urgent">⚡ Urgent (&lt; 24h SLA)</option>
                <option value="routine">🛠️ Routine (&lt; 72h SLA)</option>
                <option value="low">📋 Low Priority</option>
              </select>
            </div>

            <div className="space-y-1.5">
              <label className="text-neutral-400 font-medium">Maintenance Category</label>
              <select
                value={type}
                onChange={(e) => setType(e.target.value as WorkOrderType)}
                className="w-full bg-neutral-950 border border-neutral-800 rounded-md px-3 py-2 text-neutral-200 focus:outline-none focus:border-amber-500 capitalize"
              >
                <option value="corrective">Corrective Repair</option>
                <option value="preventive">Preventive Maintenance</option>
                <option value="inspection">Safety / Code Inspection</option>
                <option value="emergency">Emergency Breakdown</option>
              </select>
            </div>
          </div>

          {/* Technician & SLA Row */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-neutral-400 font-medium">Assign Specialist / Technician</label>
              <select
                value={assignedTechId}
                onChange={(e) => setAssignedTechId(e.target.value)}
                className="w-full bg-neutral-950 border border-neutral-800 rounded-md px-3 py-2 text-neutral-200 focus:outline-none focus:border-amber-500"
              >
                {technicians.map((t) => (
                  <option key={t.id} value={t.id}>
                    {t.name} ({t.role} · {t.activeWOs} active jobs)
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-1.5">
              <label className="text-neutral-400 font-medium">SLA Resolution Target (Hours)</label>
              <input
                type="number"
                min="1"
                max="168"
                value={slaHours}
                onChange={(e) => setSlaHours(e.target.value)}
                className="w-full bg-neutral-950 border border-neutral-800 rounded-md px-3 py-2 text-neutral-200 font-mono focus:outline-none focus:border-amber-500"
              />
            </div>
          </div>

          {/* Failure Diagnostic Code */}
          <div className="space-y-1.5">
            <label className="text-neutral-400 font-medium">Suspected Failure Code</label>
            <select
              value={failureCode}
              onChange={(e) => setFailureCode(e.target.value)}
              className="w-full bg-neutral-950 border border-neutral-800 rounded-md px-3 py-2 text-neutral-200 focus:outline-none focus:border-amber-500"
            >
              <option value="Mechanical Wear / Fatigue">Mechanical Wear / Fatigue</option>
              <option value="Electrical Short / Tripped Breaker">Electrical Short / Tripped Breaker</option>
              <option value="Hydraulic Seal Rupture / Leak">Hydraulic Seal Rupture / Leak</option>
              <option value="Refrigerant Pressure Loss">Refrigerant Pressure Loss</option>
              <option value="Sensor Drift / Calibration Error">Sensor Drift / Calibration Error</option>
              <option value="Filter Particulate Saturation">Filter Particulate Saturation</option>
              <option value="Software / BAS Protocol Fault">Software / BAS Protocol Fault</option>
            </select>
          </div>

          {/* Action Buttons */}
          <div className="pt-4 border-t border-neutral-800 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={() => setIsCreateWoOpen(false)}
              className="px-4 py-2 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 rounded font-medium transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-amber-500 hover:bg-amber-400 text-neutral-950 font-semibold rounded transition-colors shadow-sm"
            >
              Dispatch Work Order
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
