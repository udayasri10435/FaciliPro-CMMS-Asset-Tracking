import React from 'react';
import { useCMMS } from '../context/CMMSContext';
import {
  Smartphone,
  Plus,
  Building2,
  ChevronDown,
  FileCheck,
  CheckCircle2,
} from 'lucide-react';

interface HeaderProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
}

export const Header: React.FC<HeaderProps> = ({ currentTab, setCurrentTab }) => {
  const {
    facilities,
    currentFacilityId,
    setCurrentFacilityId,
    currentFacility,
    setIsCreateWoOpen,
    isMobileFieldMode,
    setIsMobileFieldMode,
    setIsComplianceReportOpen,
  } = useCMMS();

  const [isFacDropdownOpen, setIsFacDropdownOpen] = React.useState(false);

  const navItems = [
    { id: 'overview', label: 'Overview' },
    { id: 'work-orders', label: 'Work Orders' },
    { id: 'preventive', label: 'Preventive' },
    { id: 'assets', label: 'Assets' },
    { id: 'parts', label: 'Parts' },
    { id: 'floor-plan', label: 'Floor Map' },
  ];

  return (
    <header className="sticky top-0 z-40 w-full border-b border-neutral-800 bg-neutral-950/95 backdrop-blur-md">
      <div className="flex h-15 w-full items-center justify-between px-4 sm:px-6">
        {/* Zone 1: Brand Wordmark (Single text element) */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="flex h-8 w-8 items-center justify-center rounded-md bg-amber-500 text-neutral-950 font-bold tracking-tighter text-sm">
              FP
            </div>
            <a
              href="#overview"
              onClick={(e) => {
                e.preventDefault();
                setCurrentTab('overview');
              }}
              className="text-base font-semibold tracking-tight text-white hover:text-amber-400 transition-colors whitespace-nowrap"
            >
              FaciliPro CMMS
            </a>
          </div>

          {/* Industry Preset Selector */}
          <div className="relative ml-2 hidden lg:block">
            <button
              onClick={() => setIsFacDropdownOpen(!isFacDropdownOpen)}
              className="flex items-center gap-2 rounded-md border border-neutral-800 bg-neutral-900 px-2.5 py-1.5 text-xs text-neutral-300 hover:border-neutral-700 hover:text-white transition-colors"
            >
              <Building2 className="h-3.5 w-3.5 text-amber-400 shrink-0" />
              <span className="font-medium truncate max-w-[190px]">{currentFacility.name}</span>
              <ChevronDown className="h-3 w-3 text-neutral-500 shrink-0" />
            </button>

            {isFacDropdownOpen && (
              <div className="absolute left-0 mt-1.5 w-80 rounded-md border border-neutral-800 bg-neutral-900 p-1.5 shadow-2xl z-50">
                <div className="px-2 py-1 text-[11px] font-medium text-neutral-400 uppercase tracking-wider">
                  Target Facility & Industry
                </div>
                {facilities.map((fac) => (
                  <button
                    key={fac.id}
                    onClick={() => {
                      setCurrentFacilityId(fac.id);
                      setIsFacDropdownOpen(false);
                    }}
                    className={`flex w-full flex-col items-start rounded px-2.5 py-2 text-left text-xs transition-colors ${
                      fac.id === currentFacilityId
                        ? 'bg-amber-500/10 text-amber-300'
                        : 'text-neutral-300 hover:bg-neutral-800 hover:text-white'
                    }`}
                  >
                    <div className="flex w-full items-center justify-between">
                      <span className="font-medium text-neutral-200">{fac.name}</span>
                      <span className="text-[10px] text-neutral-500">{fac.industryLabel}</span>
                    </div>
                    <span className="text-[11px] text-neutral-500 mt-0.5">{fac.complianceStandard}</span>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Zone 2: Navigation Links */}
        <nav className="hidden md:flex items-center gap-6 text-xs font-medium text-neutral-400">
          {navItems.map((item) => {
            const isActive = currentTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setCurrentTab(item.id)}
                className={`transition-colors whitespace-nowrap py-1 relative ${
                  isActive
                    ? 'text-amber-400 font-semibold'
                    : 'hover:text-neutral-200'
                }`}
              >
                {item.label}
                {isActive && (
                  <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-amber-400 rounded-full" />
                )}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: Primary Actions */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          {/* Compliance Audit Report */}
          <button
            onClick={() => setIsComplianceReportOpen(true)}
            className="hidden sm:flex items-center gap-1.5 rounded-md border border-neutral-800 bg-neutral-900 px-3 py-1.5 text-xs font-medium text-neutral-300 hover:border-neutral-700 hover:text-white transition-colors"
            title="View Joint Commission / OSHA / AHERA Compliance Report"
          >
            <FileCheck className="h-3.5 w-3.5 text-emerald-400" />
            <span className="hidden xl:inline">Audit Report</span>
          </button>

          {/* Mobile Field Mode Simulator Button */}
          <button
            onClick={() => setIsMobileFieldMode(!isMobileFieldMode)}
            className={`flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-medium transition-colors ${
              isMobileFieldMode
                ? 'bg-amber-500 text-neutral-950 font-semibold'
                : 'border border-neutral-800 bg-neutral-900 text-neutral-300 hover:border-neutral-700 hover:text-white'
            }`}
            title="Switch to Rugged Technician Field Mobile Mode"
          >
            <Smartphone className="h-3.5 w-3.5" />
            <span className="whitespace-nowrap">{isMobileFieldMode ? 'Desktop Mode' : 'Field Mobile'}</span>
          </button>

          {/* Primary Action Button: + New Work Order */}
          <button
            onClick={() => setIsCreateWoOpen(true)}
            className="flex items-center gap-1.5 rounded-md bg-amber-500 px-3.5 py-1.5 text-xs font-semibold text-neutral-950 hover:bg-amber-400 transition-colors shadow-sm whitespace-nowrap"
          >
            <Plus className="h-4 w-4" />
            <span>New Work Order</span>
          </button>
        </div>
      </div>
    </header>
  );
};
