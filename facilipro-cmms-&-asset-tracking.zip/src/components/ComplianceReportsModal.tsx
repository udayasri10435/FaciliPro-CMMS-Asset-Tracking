import React from 'react';
import { useCMMS } from '../context/CMMSContext';
import {
  X,
  FileCheck,
  Download,
  Printer,
  ShieldCheck,
  CheckCircle2,
  Calendar,
  Building,
  Award,
} from 'lucide-react';

export const ComplianceReportsModal: React.FC = () => {
  const {
    isComplianceReportOpen,
    setIsComplianceReportOpen,
    currentFacility,
    workOrders,
    preventiveSchedules,
    assets,
    showToast,
  } = useCMMS();

  if (!isComplianceReportOpen) return null;

  const facilityOrders = workOrders.filter((w) => w.facilityId === currentFacility.id);
  const facilityPMs = preventiveSchedules.filter((p) => p.facilityId === currentFacility.id);
  const facilityAssets = assets.filter((a) => a.facilityId === currentFacility.id);

  const completedOrders = facilityOrders.filter(
    (w) => w.status === 'completed' || w.status === 'verified'
  );

  const handleExportCSV = () => {
    // Generate authentic CSV data
    const headers = [
      'WO Number',
      'Facility',
      'Asset Tag',
      'Asset Name',
      'Priority',
      'Status',
      'Type',
      'Technician',
      'Created Date',
      'Completed Date',
      'Labor Hours',
      'Signed Off By',
    ];

    const rows = facilityOrders.map((wo) => [
      wo.woNumber,
      `"${currentFacility.name}"`,
      wo.assetTag,
      `"${wo.assetName}"`,
      wo.priority,
      wo.status,
      wo.type,
      `"${wo.assignedTechnician.name}"`,
      wo.createdAt.split('T')[0],
      wo.completedAt ? wo.completedAt.split('T')[0] : 'N/A',
      wo.laborHoursLogged,
      `"${wo.signedOffBy || 'Pending'}"`,
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,' +
      [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute(
      'download',
      `FaciliPro_Audit_${currentFacility.code}_${new Date().toISOString().split('T')[0]}.csv`
    );
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    showToast(`Exported ${facilityOrders.length} compliance records to CSV`);
  };

  const handlePrint = () => {
    showToast('Sent audit dossier to secure print spooler');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-4 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-4xl rounded-xl border border-neutral-800 bg-neutral-900 shadow-2xl overflow-hidden my-6 max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-neutral-800 px-6 py-4 bg-neutral-950">
          <div className="flex items-center gap-2.5">
            <ShieldCheck className="h-5 w-5 text-emerald-400" />
            <div>
              <h2 className="text-base font-semibold text-white">
                Facility Compliance & Maintenance Audit Dossier
              </h2>
              <div className="text-[11px] text-neutral-400">
                Governing Body: {currentFacility.complianceBody} · Standard: {currentFacility.complianceStandard}
              </div>
            </div>
          </div>

          <button
            onClick={() => setIsComplianceReportOpen(false)}
            className="rounded p-1 text-neutral-400 hover:bg-neutral-800 hover:text-white transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Action Bar */}
        <div className="flex items-center justify-between border-b border-neutral-800 px-6 py-2.5 bg-neutral-950/70 text-xs">
          <span className="text-neutral-400">
            Official Certification Period: <strong className="text-white">Q3-Q4 2026</strong>
          </span>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 rounded text-xs font-medium transition-colors"
            >
              <Printer className="h-3.5 w-3.5" />
              <span>Print Audit Dossier</span>
            </button>
            <button
              onClick={handleExportCSV}
              className="flex items-center gap-1.5 px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-xs font-semibold transition-colors shadow-sm"
            >
              <Download className="h-3.5 w-3.5" />
              <span>Export CSV Ledger</span>
            </button>
          </div>
        </div>

        {/* Body Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 text-xs">
          {/* Certificate Badge */}
          <div className="rounded-xl border border-emerald-900/50 bg-emerald-950/20 p-5 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className="h-14 w-14 rounded-full bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 shrink-0">
                <Award className="h-8 w-8" />
              </div>
              <div className="space-y-0.5">
                <div className="text-xs uppercase font-bold tracking-wider text-emerald-400">
                  Audit Rating: 100% Exemplary Readiness
                </div>
                <div className="text-base font-bold text-white">
                  {currentFacility.name}
                </div>
                <div className="text-neutral-400 text-[11px]">
                  All preventive maintenance cycles, emergency response logs, and technician credentials meet or exceed {currentFacility.complianceBody} mandates.
                </div>
              </div>
            </div>

            <div className="text-right shrink-0">
              <div className="text-2xl font-bold font-mono text-emerald-400 tabular-nums">
                {currentFacility.pmComplianceRate}%
              </div>
              <div className="text-[10px] text-neutral-400 uppercase">PM On-Time Adherence</div>
            </div>
          </div>

          {/* Audit Metrics Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="rounded-lg border border-neutral-800 bg-neutral-950 p-3">
              <div className="text-[10px] text-neutral-500 uppercase">Tracked Assets</div>
              <div className="text-xl font-bold font-mono text-white mt-1 tabular-nums">
                {facilityAssets.length} Units
              </div>
              <div className="text-[10px] text-neutral-400 mt-0.5">100% Barcode Indexed</div>
            </div>

            <div className="rounded-lg border border-neutral-800 bg-neutral-950 p-3">
              <div className="text-[10px] text-neutral-500 uppercase">Preventive Schedules</div>
              <div className="text-xl font-bold font-mono text-amber-400 mt-1 tabular-nums">
                {facilityPMs.length} Active
              </div>
              <div className="text-[10px] text-neutral-400 mt-0.5">Auto-generated cadences</div>
            </div>

            <div className="rounded-lg border border-neutral-800 bg-neutral-950 p-3">
              <div className="text-[10px] text-neutral-500 uppercase">Completed & Signed</div>
              <div className="text-xl font-bold font-mono text-emerald-400 mt-1 tabular-nums">
                {completedOrders.length} Tickets
              </div>
              <div className="text-[10px] text-neutral-400 mt-0.5">Digital sign-off verified</div>
            </div>

            <div className="rounded-lg border border-neutral-800 bg-neutral-950 p-3">
              <div className="text-[10px] text-neutral-500 uppercase">Next Inspection</div>
              <div className="text-xl font-bold font-mono text-neutral-200 mt-1">
                Oct 2026
              </div>
              <div className="text-[10px] text-neutral-400 mt-0.5">Annual onsite evaluation</div>
            </div>
          </div>

          {/* Compliance Log Table */}
          <div className="rounded-lg border border-neutral-800 bg-neutral-950 p-4 space-y-3">
            <div className="font-semibold uppercase tracking-wider text-neutral-200 text-xs">
              Recent Audited Maintenance Interventions
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="border-b border-neutral-800 text-[11px] text-neutral-400 uppercase font-mono">
                  <tr>
                    <th className="py-2">Ticket #</th>
                    <th className="py-2">Machine Tag</th>
                    <th className="py-2">Type</th>
                    <th className="py-2">Compliance Verification</th>
                    <th className="py-2">Sign-Off Authority</th>
                    <th className="py-2 text-right">Timestamp</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-900 text-neutral-300">
                  {facilityOrders.map((wo) => (
                    <tr key={wo.id}>
                      <td className="py-2 font-mono font-bold text-amber-400">{wo.woNumber}</td>
                      <td className="py-2 font-mono">{wo.assetTag}</td>
                      <td className="py-2 capitalize">{wo.type}</td>
                      <td className="py-2">
                        <span className="text-emerald-400 flex items-center gap-1 font-mono text-[11px]">
                          <CheckCircle2 className="h-3 w-3" />
                          <span>{currentFacility.complianceStandard.split('/')[0]}</span>
                        </span>
                      </td>
                      <td className="py-2 text-neutral-200 font-medium">
                        {wo.signedOffBy || 'Pending Signature'}
                      </td>
                      <td className="py-2 text-right font-mono text-neutral-400">
                        {new Date(wo.createdAt).toLocaleDateString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="border-t border-neutral-800 px-6 py-3 bg-neutral-950 flex items-center justify-between">
          <div className="text-[11px] text-neutral-500 font-mono">
            Report Hash: SHA256-FACILIPRO-{currentFacility.code}-VERIFIED
          </div>
          <button
            onClick={() => setIsComplianceReportOpen(false)}
            className="px-4 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-white rounded font-medium transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
