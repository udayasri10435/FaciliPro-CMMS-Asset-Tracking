import React, { useState } from 'react';
import { useCMMS } from '../context/CMMSContext';
import { Asset, AssetCategory, AssetStatus } from '../types/cmms';
import {
  Search,
  Filter,
  QrCode,
  MapPin,
  Wrench,
  Clock,
  Activity,
  CheckCircle2,
  AlertTriangle,
  ArrowUpRight,
  ShieldCheck,
  Cpu,
} from 'lucide-react';

export const AssetRegistryView: React.FC = () => {
  const {
    assets,
    currentFacility,
    setSelectedAssetId,
    setIsCreateWoOpen,
    setIsFloorPlanOpen,
    setIsQrScannerOpen,
  } = useCMMS();

  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  const facilityAssets = assets.filter((a) => a.facilityId === currentFacility.id);

  const categories = Array.from(new Set(facilityAssets.map((a) => a.category)));

  const filteredAssets = facilityAssets.filter((asset) => {
    const matchesSearch =
      asset.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      asset.assetTag.toLowerCase().includes(searchQuery.toLowerCase()) ||
      asset.model.toLowerCase().includes(searchQuery.toLowerCase()) ||
      asset.serialNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      asset.location.room.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesCategory = categoryFilter === 'all' || asset.category === categoryFilter;
    const matchesStatus = statusFilter === 'all' || asset.status === statusFilter;

    return matchesSearch && matchesCategory && matchesStatus;
  });

  const getStatusColor = (status: AssetStatus) => {
    switch (status) {
      case 'operational':
        return 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20';
      case 'needs_service':
        return 'text-amber-400 bg-amber-500/10 border-amber-500/20';
      case 'under_repair':
        return 'text-blue-400 bg-blue-500/10 border-blue-500/20';
      case 'critical_down':
        return 'text-rose-400 bg-rose-500/10 border-rose-500/20';
    }
  };

  const getHealthColor = (score: number) => {
    if (score >= 90) return 'text-emerald-400';
    if (score >= 70) return 'text-amber-400';
    return 'text-rose-400';
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Search & Filter Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 bg-neutral-900/60 p-4 rounded-lg border border-neutral-800">
        <div className="flex flex-1 items-center gap-3">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-neutral-500" />
            <input
              type="text"
              placeholder="Search asset tag, model, serial, or room..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-neutral-950 border border-neutral-800 rounded-md pl-9 pr-3 py-1.5 text-xs text-neutral-200 placeholder-neutral-500 focus:outline-none focus:border-amber-500"
            />
          </div>

          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="bg-neutral-950 border border-neutral-800 rounded-md px-2.5 py-1.5 text-xs text-neutral-300 focus:outline-none focus:border-amber-500"
          >
            <option value="all">All Categories</option>
            {categories.map((cat) => (
              <option key={cat} value={cat}>
                {cat}
              </option>
            ))}
          </select>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="hidden sm:block bg-neutral-950 border border-neutral-800 rounded-md px-2.5 py-1.5 text-xs text-neutral-300 focus:outline-none focus:border-amber-500"
          >
            <option value="all">All Statuses</option>
            <option value="operational">Operational</option>
            <option value="needs_service">Needs Service</option>
            <option value="under_repair">Under Repair</option>
            <option value="critical_down">Critical Down</option>
          </select>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsQrScannerOpen(true)}
            className="flex items-center gap-1.5 border border-neutral-800 bg-neutral-950 hover:bg-neutral-800 text-neutral-200 px-3 py-1.5 rounded-md text-xs font-medium transition-colors"
          >
            <QrCode className="h-4 w-4 text-amber-400" />
            <span>Scan QR</span>
          </button>
          <button
            onClick={() => setIsFloorPlanOpen(true)}
            className="flex items-center gap-1.5 border border-neutral-800 bg-neutral-950 hover:bg-neutral-800 text-neutral-200 px-3 py-1.5 rounded-md text-xs font-medium transition-colors"
          >
            <MapPin className="h-4 w-4 text-blue-400" />
            <span>Floor Plan Pins</span>
          </button>
        </div>
      </div>

      {/* Asset Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredAssets.length === 0 ? (
          <div className="col-span-3 rounded-lg border border-neutral-800 bg-neutral-900/40 p-12 text-center text-neutral-500 text-xs">
            No equipment assets match your filter criteria.
          </div>
        ) : (
          filteredAssets.map((asset) => {
            const statusStyle = getStatusColor(asset.status);
            const healthColor = getHealthColor(asset.healthScore);

            return (
              <div
                key={asset.id}
                onClick={() => setSelectedAssetId(asset.id)}
                className="rounded-lg border border-neutral-800 bg-neutral-900/80 p-5 space-y-4 hover:border-neutral-700 transition-all cursor-pointer flex flex-col justify-between group shadow-sm hover:shadow"
              >
                <div className="space-y-3">
                  {/* Top Bar */}
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="flex items-center gap-2 text-xs font-mono">
                        <span className="text-amber-400 font-bold">{asset.assetTag}</span>
                        <span aria-hidden="true" className="text-neutral-600">·</span>
                        <span className="text-neutral-400">{asset.criticality.split(' - ')[0]}</span>
                      </div>
                      <h3 className="text-sm font-bold text-white group-hover:text-amber-300 transition-colors mt-0.5">
                        {asset.name}
                      </h3>
                    </div>

                    <span
                      className={`text-[10px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded border ${statusStyle}`}
                    >
                      {asset.status.replace('_', ' ')}
                    </span>
                  </div>

                  {/* Location & Specs snippet */}
                  <div className="text-xs space-y-1 bg-neutral-950/60 p-3 rounded border border-neutral-800/80">
                    <div className="flex items-center justify-between text-neutral-400">
                      <span>Location:</span>
                      <span className="text-neutral-200 font-medium truncate max-w-[180px]">
                        {asset.location.room} ({asset.location.floor})
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-neutral-400">
                      <span>Manufacturer:</span>
                      <span className="text-neutral-200">{asset.manufacturer}</span>
                    </div>
                    <div className="flex items-center justify-between text-neutral-400">
                      <span>Model:</span>
                      <span className="text-neutral-200 font-mono text-[11px]">{asset.model}</span>
                    </div>
                  </div>

                  {/* Health Score & Reliability Telemetry */}
                  <div className="grid grid-cols-3 gap-2 text-center pt-1 border-t border-neutral-800/60">
                    <div className="bg-neutral-950 p-2 rounded">
                      <div className="text-[10px] text-neutral-500 uppercase">Health</div>
                      <div className={`text-base font-bold font-mono tabular-nums ${healthColor}`}>
                        {asset.healthScore}%
                      </div>
                    </div>
                    <div className="bg-neutral-950 p-2 rounded">
                      <div className="text-[10px] text-neutral-500 uppercase">Uptime</div>
                      <div className="text-base font-bold font-mono tabular-nums text-white">
                        {asset.uptimePercentage}%
                      </div>
                    </div>
                    <div className="bg-neutral-950 p-2 rounded">
                      <div className="text-[10px] text-neutral-500 uppercase">MTTR</div>
                      <div className="text-base font-bold font-mono tabular-nums text-amber-400">
                        {asset.mttrHours}h
                      </div>
                    </div>
                  </div>
                </div>

                {/* Card Action Footer */}
                <div className="pt-3 border-t border-neutral-800/80 flex items-center justify-between text-xs text-neutral-500">
                  <span className="font-mono text-[11px]">PM Due: {asset.nextPmDueDate}</span>
                  <div className="flex items-center gap-1 text-amber-400 font-medium group-hover:text-amber-300">
                    <span>Inspect Dossier</span>
                    <ArrowUpRight className="h-3.5 w-3.5" />
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
