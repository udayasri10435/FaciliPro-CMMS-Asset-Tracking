import React, { useState } from 'react';
import { useCMMS } from '../context/CMMSContext';
import {
  X,
  MapPin,
  AlertTriangle,
  CheckCircle2,
  Wrench,
  Layers,
  ZoomIn,
  ZoomOut,
  Maximize2,
  Activity,
  ArrowUpRight,
} from 'lucide-react';

export const FloorPlanModal: React.FC = () => {
  const {
    isFloorPlanOpen,
    setIsFloorPlanOpen,
    currentFacility,
    assets,
    setSelectedAssetId,
    setSelectedWorkOrderId,
  } = useCMMS();

  const [activePinAssetId, setActivePinAssetId] = useState<string | null>(null);
  const [selectedZone, setSelectedZone] = useState<string>('all');

  if (!isFloorPlanOpen) return null;

  const facilityAssets = assets.filter((a) => a.facilityId === currentFacility.id);

  const zones = Array.from(new Set(facilityAssets.map((a) => a.location.zone)));

  const activeAsset = facilityAssets.find((a) => a.id === activePinAssetId);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-5xl rounded-xl border border-neutral-800 bg-neutral-900 shadow-2xl overflow-hidden my-6 max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-neutral-800 px-6 py-4 bg-neutral-950">
          <div className="flex items-center gap-2.5">
            <MapPin className="h-5 w-5 text-blue-400" />
            <div>
              <h2 className="text-base font-semibold text-white">
                Interactive Facility Floor Map & Machine Spatial Pins
              </h2>
              <div className="text-[11px] text-neutral-400">
                {currentFacility.name} · {currentFacility.squareFeet.toLocaleString()} sq ft CAD Grid
              </div>
            </div>
          </div>

          <button
            onClick={() => setIsFloorPlanOpen(false)}
            className="rounded p-1 text-neutral-400 hover:bg-neutral-800 hover:text-white transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Filter bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-neutral-800 px-6 py-2.5 bg-neutral-950/70 text-xs">
          <div className="flex items-center gap-2">
            <span className="text-neutral-400">Filter Zone:</span>
            <select
              value={selectedZone}
              onChange={(e) => setSelectedZone(e.target.value)}
              className="bg-neutral-900 border border-neutral-800 rounded px-2.5 py-1 text-neutral-200 focus:outline-none focus:border-amber-500 text-xs"
            >
              <option value="all">All Facility Zones</option>
              {zones.map((z) => (
                <option key={z} value={z}>
                  {z}
                </option>
              ))}
            </select>
          </div>

          {/* Legend */}
          <div className="flex items-center gap-4 text-[11px]">
            <div className="flex items-center gap-1.5 text-emerald-400">
              <span className="h-2 w-2 rounded-full bg-emerald-400 inline-block" />
              <span>Operational</span>
            </div>
            <div className="flex items-center gap-1.5 text-amber-400">
              <span className="h-2 w-2 rounded-full bg-amber-400 inline-block" />
              <span>Needs Service</span>
            </div>
            <div className="flex items-center gap-1.5 text-blue-400">
              <span className="h-2 w-2 rounded-full bg-blue-400 inline-block" />
              <span>Under Repair</span>
            </div>
            <div className="flex items-center gap-1.5 text-rose-400">
              <span className="h-2 w-2 rounded-full bg-rose-400 inline-block animate-ping" />
              <span>Critical Down</span>
            </div>
          </div>
        </div>

        {/* Main Floor Plan Canvas */}
        <div className="relative flex-1 bg-neutral-950 p-6 flex items-center justify-center min-h-[440px] overflow-hidden select-none">
          {/* SVG Blueprint Background */}
          <svg
            className="w-full h-full max-h-[460px] rounded-lg border border-neutral-800/80 bg-[#0c1017] shadow-inner"
            viewBox="0 0 1000 600"
            xmlns="http://www.w3.org/2000/svg"
          >
            {/* Grid Pattern */}
            <defs>
              <pattern id="cad-grid" width="40" height="40" patternUnits="userSpaceOnUse">
                <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#172234" strokeWidth="0.8" />
              </pattern>
            </defs>
            <rect width="1000" height="600" fill="url(#cad-grid)" />

            {/* Perimeter Facility Outer Wall */}
            <rect
              x="50"
              y="50"
              width="900"
              height="500"
              fill="none"
              stroke="#2c3e55"
              strokeWidth="3"
              rx="8"
            />

            {/* Zone Divisions based on Industry */}
            {currentFacility.industry === 'hospital' && (
              <g stroke="#1e2c3f" strokeWidth="2" fill="none">
                {/* Pavilion A (Surgical) */}
                <rect x="70" y="70" width="380" height="230" fill="#0f1926" fillOpacity="0.5" />
                <text x="90" y="100" fill="#476282" fontSize="14" fontFamily="monospace" fontWeight="bold">
                  ZONE 1 // SURGICAL PAVILION A & CENTRAL CHILLER
                </text>

                {/* Pavilion B (Clinical Sterile Core) */}
                <rect x="470" y="70" width="460" height="230" fill="#0f1926" fillOpacity="0.5" />
                <text x="490" y="100" fill="#476282" fontSize="14" fontFamily="monospace" fontWeight="bold">
                  ZONE 2 // CLINICAL CORE & STERILE PROCESSING
                </text>

                {/* Emergency Dept */}
                <rect x="70" y="320" width="450" height="210" fill="#0f1926" fillOpacity="0.5" />
                <text x="90" y="350" fill="#476282" fontSize="14" fontFamily="monospace" fontWeight="bold">
                  ZONE 3 // EMERGENCY WING & DIAGNOSTIC LABS
                </text>

                {/* Central Utility Yard */}
                <rect x="540" y="320" width="390" height="210" fill="#141a24" fillOpacity="0.5" />
                <text x="560" y="350" fill="#476282" fontSize="14" fontFamily="monospace" fontWeight="bold">
                  ZONE 4 // CENTRAL UTILITY YARD & GENERATOR 1500kVA
                </text>
              </g>
            )}

            {currentFacility.industry === 'school' && (
              <g stroke="#1e2c3f" strokeWidth="2" fill="none">
                <rect x="70" y="70" width="420" height="230" fill="#0f1926" fillOpacity="0.5" />
                <text x="90" y="100" fill="#476282" fontSize="14" fontFamily="monospace" fontWeight="bold">
                  ZONE NORTH // CURIE SCIENCE & TECH BUILDING
                </text>

                <rect x="510" y="70" width="420" height="230" fill="#0f1926" fillOpacity="0.5" />
                <text x="530" y="100" fill="#476282" fontSize="14" fontFamily="monospace" fontWeight="bold">
                  ZONE EAST // ATHLETIC ARENA & FIELDHOUSE
                </text>

                <rect x="70" y="320" width="860" height="210" fill="#0f1926" fillOpacity="0.5" />
                <text x="90" y="350" fill="#476282" fontSize="14" fontFamily="monospace" fontWeight="bold">
                  ZONE SOUTH // STUDENT UNION & DISTRICT CENTRAL CAFETERIA
                </text>
              </g>
            )}

            {currentFacility.industry === 'office' && (
              <g stroke="#1e2c3f" strokeWidth="2" fill="none">
                <rect x="70" y="70" width="860" height="150" fill="#0f1926" fillOpacity="0.5" />
                <text x="90" y="100" fill="#476282" fontSize="14" fontFamily="monospace" fontWeight="bold">
                  PENTHOUSE LEVEL 53 // ELEVATOR MACHINE ROOM & REGEN DRIVES
                </text>

                <rect x="70" y="240" width="860" height="160" fill="#0f1926" fillOpacity="0.5" />
                <text x="90" y="270" fill="#476282" fontSize="14" fontFamily="monospace" fontWeight="bold">
                  FLOOR 14 // MISSION CRITICAL ENTERPRISE SERVER DATA CENTER
                </text>

                <rect x="70" y="420" width="860" height="110" fill="#0f1926" fillOpacity="0.5" />
                <text x="90" y="450" fill="#476282" fontSize="14" fontFamily="monospace" fontWeight="bold">
                  SUB-BASEMENT B3 // MAIN 4160V PRIMARY ELECTRICAL VAULT
                </text>
              </g>
            )}

            {currentFacility.industry === 'warehouse' && (
              <g stroke="#1e2c3f" strokeWidth="2" fill="none">
                <rect x="70" y="70" width="860" height="200" fill="#0f1926" fillOpacity="0.5" />
                <text x="90" y="100" fill="#476282" fontSize="14" fontFamily="monospace" fontWeight="bold">
                  MEZZANINE SPINE // HIGH-SPEED SHOE SORTER LOOP S-1
                </text>

                <rect x="70" y="290" width="420" height="240" fill="#0f1926" fillOpacity="0.5" />
                <text x="90" y="320" fill="#476282" fontSize="14" fontFamily="monospace" fontWeight="bold">
                  BAY A-C // VERY NARROW AISLE (VNA) AUTOMATED FORKLIFTS
                </text>

                <rect x="510" y="290" width="420" height="240" fill="#0f1926" fillOpacity="0.5" />
                <text x="530" y="320" fill="#476282" fontSize="14" fontFamily="monospace" fontWeight="bold">
                  APRON TERMINAL // INBOUND HYDRAULIC DOCK LEVELERS (BAYS 1-24)
                </text>
              </g>
            )}
          </svg>

          {/* Asset Interactive Pins Overlay */}
          {facilityAssets.map((asset) => {
            const coords = asset.location.coordinates || { x: 50, y: 50 };
            const isCriticalDown = asset.status === 'critical_down';
            const isUnderRepair = asset.status === 'under_repair';
            const isNeedsService = asset.status === 'needs_service';
            const isSelected = activePinAssetId === asset.id;

            return (
              <div
                key={asset.id}
                style={{
                  left: `${coords.x}%`,
                  top: `${coords.y}%`,
                }}
                onClick={() => setActivePinAssetId(asset.id)}
                className="absolute -translate-x-1/2 -translate-y-1/2 cursor-pointer z-10 group"
              >
                {/* Ping animation if critical or needs service */}
                {isCriticalDown && (
                  <span className="absolute -inset-2 rounded-full bg-rose-500/40 animate-ping" />
                )}
                {isNeedsService && (
                  <span className="absolute -inset-1.5 rounded-full bg-amber-500/30 animate-pulse" />
                )}

                {/* Pin Circle */}
                <div
                  className={`h-7 w-7 rounded-full flex items-center justify-center text-xs font-bold font-mono transition-transform duration-200 border-2 shadow-lg ${
                    isCriticalDown
                      ? 'bg-rose-600 text-white border-rose-300 scale-110'
                      : isNeedsService
                      ? 'bg-amber-500 text-neutral-950 border-amber-300'
                      : isUnderRepair
                      ? 'bg-blue-600 text-white border-blue-300'
                      : 'bg-emerald-600 text-white border-emerald-300'
                  } ${isSelected ? 'ring-4 ring-white ring-offset-2 ring-offset-neutral-950 scale-125' : 'hover:scale-115'}`}
                >
                  <MapPin className="h-3.5 w-3.5 fill-current" />
                </div>

                {/* Floating Tag Label */}
                <div className="absolute left-1/2 -translate-x-1/2 top-8 whitespace-nowrap bg-neutral-900/90 text-[10px] font-mono font-bold px-1.5 py-0.5 rounded border border-neutral-700 text-neutral-200 pointer-events-none group-hover:block hidden shadow">
                  {asset.assetTag}
                </div>
              </div>
            );
          })}
        </div>

        {/* Selected Asset Bottom Drawer / Preview Card */}
        {activeAsset && (
          <div className="border-t border-neutral-800 bg-neutral-950 p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2 text-xs">
                <span className="font-mono text-amber-400 font-bold">{activeAsset.assetTag}</span>
                <span aria-hidden="true" className="text-neutral-600">·</span>
                <span className="text-neutral-400 font-medium">{activeAsset.category}</span>
                <span aria-hidden="true" className="text-neutral-600">·</span>
                <span className="capitalize text-neutral-300 font-semibold">{activeAsset.status.replace('_', ' ')}</span>
              </div>
              <h3 className="text-sm font-bold text-white">{activeAsset.name}</h3>
              <p className="text-xs text-neutral-400">
                Location: {activeAsset.location.building} · {activeAsset.location.room} ({activeAsset.location.zone})
              </p>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              {activeAsset.activeWorkOrderId && (
                <button
                  onClick={() => {
                    setIsFloorPlanOpen(false);
                    setSelectedWorkOrderId(activeAsset.activeWorkOrderId || null);
                  }}
                  className="px-3 py-1.5 bg-rose-600 hover:bg-rose-500 text-white rounded text-xs font-semibold transition-colors flex items-center gap-1"
                >
                  <AlertTriangle className="h-3.5 w-3.5" />
                  <span>Open Active Ticket</span>
                </button>
              )}

              <button
                onClick={() => {
                  setIsFloorPlanOpen(false);
                  setSelectedAssetId(activeAsset.id);
                }}
                className="px-3.5 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-white rounded text-xs font-medium transition-colors flex items-center gap-1"
              >
                <span>Inspect Dossier</span>
                <ArrowUpRight className="h-3.5 w-3.5" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
