import React, { useState } from 'react';
import { useCMMS } from '../context/CMMSContext';
import {
  X,
  QrCode,
  Camera,
  CheckCircle2,
  Wrench,
  Search,
  ArrowRight,
  Sparkles,
} from 'lucide-react';

export const QrScannerModal: React.FC = () => {
  const {
    isQrScannerOpen,
    setIsQrScannerOpen,
    currentFacility,
    assets,
    setSelectedAssetId,
    setIsCreateWoOpen,
    showToast,
  } = useCMMS();

  const [simulatedTagInput, setSimulatedTagInput] = useState('');
  const [scannedAsset, setScannedAsset] = useState<any | null>(null);

  if (!isQrScannerOpen) return null;

  const facilityAssets = assets.filter((a) => a.facilityId === currentFacility.id);

  const handleSimulateScan = (asset: any) => {
    setScannedAsset(asset);
    showToast(`Decoded QR: ${asset.assetTag} (${asset.name})`);
  };

  const handleManualSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!simulatedTagInput.trim()) return;
    const found = facilityAssets.find(
      (a) =>
        a.assetTag.toLowerCase() === simulatedTagInput.trim().toLowerCase() ||
        a.qrCodeData.toLowerCase().includes(simulatedTagInput.trim().toLowerCase())
    );
    if (found) {
      setScannedAsset(found);
      showToast(`Asset Found: ${found.assetTag}`);
    } else {
      showToast(`No equipment registered under tag "${simulatedTagInput}"`);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-4 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-lg rounded-xl border border-neutral-800 bg-neutral-900 shadow-2xl overflow-hidden my-6">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-neutral-800 px-6 py-4 bg-neutral-950">
          <div className="flex items-center gap-2">
            <Camera className="h-5 w-5 text-amber-400" />
            <h2 className="text-base font-semibold text-white">
              Field Asset QR / Barcode Scanner
            </h2>
          </div>
          <button
            onClick={() => {
              setIsQrScannerOpen(false);
              setScannedAsset(null);
            }}
            className="rounded p-1 text-neutral-400 hover:bg-neutral-800 hover:text-white transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Viewfinder Area */}
        <div className="p-6 space-y-5">
          {!scannedAsset ? (
            <>
              {/* Simulated Camera Viewfinder with Scanner laser */}
              <div className="relative mx-auto h-56 w-full max-w-xs rounded-lg border-2 border-neutral-700 bg-neutral-950 overflow-hidden flex items-center justify-center shadow-inner">
                {/* Viewfinder corner brackets */}
                <div className="absolute top-2 left-2 w-6 h-6 border-t-2 border-l-2 border-amber-400" />
                <div className="absolute top-2 right-2 w-6 h-6 border-t-2 border-r-2 border-amber-400" />
                <div className="absolute bottom-2 left-2 w-6 h-6 border-b-2 border-l-2 border-amber-400" />
                <div className="absolute bottom-2 right-2 w-6 h-6 border-b-2 border-r-2 border-amber-400" />

                {/* Animated Laser Scanning Line */}
                <div className="absolute left-0 right-0 h-0.5 bg-gradient-to-r from-transparent via-amber-400 to-transparent shadow-[0_0_10px_#f59e0b] animate-bounce" />

                {/* Center QR Graphic */}
                <div className="opacity-20 text-neutral-400">
                  <QrCode className="h-28 w-28" />
                </div>

                <div className="absolute bottom-3 text-[11px] font-mono text-neutral-400 bg-neutral-900/80 px-2 py-0.5 rounded">
                  Align optical tag in viewfinder
                </div>
              </div>

              {/* Sample QR Barcodes from Current Facility for Instant 1-Click Test */}
              <div className="space-y-2">
                <div className="text-[11px] font-semibold uppercase tracking-wider text-neutral-400">
                  Quick-Scan Machine Tags ({currentFacility.industryLabel}):
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {facilityAssets.map((asset) => (
                    <button
                      key={asset.id}
                      onClick={() => handleSimulateScan(asset)}
                      className="flex items-center justify-between p-2 rounded bg-neutral-950 border border-neutral-800 hover:border-amber-500/50 hover:bg-neutral-800/60 text-left transition-all group"
                    >
                      <div className="truncate pr-2">
                        <div className="font-mono text-xs text-amber-400 font-bold group-hover:text-amber-300">
                          {asset.assetTag}
                        </div>
                        <div className="text-[11px] text-neutral-300 truncate">
                          {asset.name}
                        </div>
                      </div>
                      <QrCode className="h-4 w-4 text-neutral-500 group-hover:text-amber-400 shrink-0" />
                    </button>
                  ))}
                </div>
              </div>

              {/* Manual Input Form */}
              <form onSubmit={handleManualSearch} className="flex gap-2 pt-2 border-t border-neutral-800">
                <input
                  type="text"
                  placeholder="Or enter tag manually (e.g. AST-HOSP-701)..."
                  value={simulatedTagInput}
                  onChange={(e) => setSimulatedTagInput(e.target.value)}
                  className="flex-1 bg-neutral-950 border border-neutral-800 rounded px-3 py-1.5 text-xs text-neutral-200 placeholder-neutral-500 focus:outline-none focus:border-amber-500 font-mono"
                />
                <button
                  type="submit"
                  className="px-3 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-medium rounded transition-colors"
                >
                  Lookup
                </button>
              </form>
            </>
          ) : (
            /* Scanned Match Result */
            <div className="space-y-4">
              <div className="rounded-lg border border-emerald-500/30 bg-emerald-950/20 p-4 space-y-3">
                <div className="flex items-center gap-2 text-emerald-400 text-xs font-semibold">
                  <CheckCircle2 className="h-5 w-5 shrink-0" />
                  <span>Equipment Tag Authenticated</span>
                </div>

                <div className="space-y-1">
                  <div className="text-lg font-bold text-white">{scannedAsset.name}</div>
                  <div className="font-mono text-xs text-amber-400 font-semibold">
                    {scannedAsset.assetTag} · Model: {scannedAsset.model}
                  </div>
                  <div className="text-xs text-neutral-300">
                    Location: {scannedAsset.location.building} · {scannedAsset.location.room}
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-2 pt-2 border-t border-emerald-900/40 text-center text-xs">
                  <div>
                    <span className="text-[10px] text-neutral-400 block uppercase">Health</span>
                    <span className="font-mono font-bold text-emerald-400">{scannedAsset.healthScore}%</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-neutral-400 block uppercase">State</span>
                    <span className="font-mono text-neutral-200 capitalize">{scannedAsset.status.replace('_', ' ')}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-neutral-400 block uppercase">Uptime</span>
                    <span className="font-mono text-neutral-200">{scannedAsset.uptimePercentage}%</span>
                  </div>
                </div>
              </div>

              {/* Actions for this Scanned Asset */}
              <div className="flex flex-col sm:flex-row gap-2.5">
                <button
                  onClick={() => {
                    setIsQrScannerOpen(false);
                    setSelectedAssetId(scannedAsset.id);
                  }}
                  className="flex-1 py-2 px-3 bg-neutral-800 hover:bg-neutral-700 text-white rounded text-xs font-medium transition-colors flex items-center justify-center gap-1.5"
                >
                  <span>View Machine Dossier</span>
                  <ArrowRight className="h-3.5 w-3.5" />
                </button>

                <button
                  onClick={() => {
                    setIsQrScannerOpen(false);
                    setIsCreateWoOpen(true);
                  }}
                  className="flex-1 py-2 px-3 bg-amber-500 hover:bg-amber-400 text-neutral-950 font-semibold rounded text-xs transition-colors flex items-center justify-center gap-1.5"
                >
                  <Wrench className="h-3.5 w-3.5" />
                  <span>Log Work Order Now</span>
                </button>
              </div>

              <div className="text-center pt-1">
                <button
                  onClick={() => setScannedAsset(null)}
                  className="text-xs text-neutral-500 hover:text-neutral-300 underline"
                >
                  ← Scan Another Asset
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
