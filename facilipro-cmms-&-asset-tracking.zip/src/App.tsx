import React, { useState } from 'react';
import { CMMSProvider, useCMMS } from './context/CMMSContext';
import { Header } from './components/Header';
import { DashboardOverview } from './components/DashboardOverview';
import { WorkOrdersView } from './components/WorkOrdersView';
import { PreventiveMaintenanceView } from './components/PreventiveMaintenanceView';
import { AssetRegistryView } from './components/AssetRegistryView';
import { InventoryView } from './components/InventoryView';
import { TechnicianMobileView } from './components/TechnicianMobileView';
import { WorkOrderDetailModal } from './components/WorkOrderDetailModal';
import { CreateWorkOrderModal } from './components/CreateWorkOrderModal';
import { AssetDetailModal } from './components/AssetDetailModal';
import { FloorPlanModal } from './components/FloorPlanModal';
import { QrScannerModal } from './components/QrScannerModal';
import { ComplianceReportsModal } from './components/ComplianceReportsModal';
import {
  CheckCircle2,
  ShieldCheck,
  Building2,
  Wrench,
  Smartphone,
  ExternalLink,
} from 'lucide-react';

const CMMSMainApp: React.FC = () => {
  const [currentTab, setCurrentTab] = useState<string>('overview');
  const {
    isMobileFieldMode,
    setIsFloorPlanOpen,
    toastMessage,
    currentFacility,
  } = useCMMS();

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 flex flex-col font-sans selection:bg-amber-500 selection:text-neutral-950">
      {/* Top Bar Header */}
      <Header currentTab={currentTab} setCurrentTab={setCurrentTab} />

      {/* Main Viewport Container */}
      <main className="flex-1 w-full max-w-7xl mx-auto px-4 sm:px-6 pt-6">
        {isMobileFieldMode ? (
          <TechnicianMobileView />
        ) : (
          <>
            {currentTab === 'overview' && (
              <DashboardOverview onNavigateToTab={setCurrentTab} />
            )}
            {currentTab === 'work-orders' && <WorkOrdersView />}
            {currentTab === 'preventive' && <PreventiveMaintenanceView />}
            {currentTab === 'assets' && <AssetRegistryView />}
            {currentTab === 'parts' && <InventoryView />}
            {currentTab === 'floor-plan' && (
              <div className="space-y-4 pb-12">
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="text-xl font-bold text-white">Facility Spatial Blueprint</h2>
                    <p className="text-xs text-neutral-400">
                      Floor plan and equipment distribution for {currentFacility.name}
                    </p>
                  </div>
                  <button
                    onClick={() => setIsFloorPlanOpen(true)}
                    className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-neutral-950 font-semibold rounded text-xs transition-colors"
                  >
                    Open Fullscreen CAD Inspector
                  </button>
                </div>
                <div
                  onClick={() => setIsFloorPlanOpen(true)}
                  className="rounded-xl border border-neutral-800 bg-neutral-900/60 p-8 text-center cursor-pointer hover:border-neutral-700 transition-all group"
                >
                  <Building2 className="h-12 w-12 text-amber-400 mx-auto mb-3 group-hover:scale-110 transition-transform" />
                  <h3 className="text-base font-bold text-white">Interactive CAD Floor Map</h3>
                  <p className="text-xs text-neutral-400 max-w-md mx-auto mt-1">
                    Click to launch the interactive zone schematic with real-time asset telemetry pins, emergency flash alerts, and equipment routing.
                  </p>
                  <span className="inline-block mt-4 px-3 py-1.5 bg-neutral-800 text-neutral-200 text-xs font-medium rounded-md group-hover:bg-neutral-700">
                    Launch Interactive Map →
                  </span>
                </div>
              </div>
            )}
          </>
        )}
      </main>

      {/* Global Modals */}
      <WorkOrderDetailModal />
      <CreateWorkOrderModal />
      <AssetDetailModal />
      <FloorPlanModal />
      <QrScannerModal />
      <ComplianceReportsModal />

      {/* Global Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-5 right-5 z-50 flex items-center gap-2.5 rounded-lg border border-amber-500/40 bg-neutral-900 px-4 py-3 shadow-2xl text-xs text-white animate-fade-in backdrop-blur-md">
          <CheckCircle2 className="h-4 w-4 text-amber-400 shrink-0" />
          <span className="font-medium">{toastMessage}</span>
        </div>
      )}

      {/* Quiet Footer */}
      <footer className="w-full border-t border-neutral-900 bg-neutral-950 py-6 text-xs text-neutral-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-neutral-400">FaciliPro CMMS</span>
            <span aria-hidden="true">·</span>
            <span>Enterprise Facility & Asset Management Platform</span>
          </div>

          <div className="flex items-center gap-4 text-neutral-400">
            <span>Healthcare</span>
            <span>Education</span>
            <span>Commercial</span>
            <span>Logistics</span>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default function App() {
  return (
    <CMMSProvider>
      <CMMSMainApp />
    </CMMSProvider>
  );
}
