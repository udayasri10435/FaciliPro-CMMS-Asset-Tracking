export type IndustryType = 'hospital' | 'school' | 'office' | 'warehouse';

export interface Facility {
  id: string;
  name: string;
  code: string;
  industry: IndustryType;
  industryLabel: string;
  address: string;
  squareFeet: number;
  buildingsCount: number;
  activeAssetsCount: number;
  openWoCount: number;
  pmComplianceRate: number;
  complianceBody: string;
  complianceStandard: string;
}

export type AssetCategory =
  | 'HVAC & Climate'
  | 'Electrical & Power'
  | 'Plumbing & Water'
  | 'Life Safety & Fire'
  | 'Material Handling'
  | 'Biomedical & Lab'
  | 'Vertical Transport'
  | 'Building Envelope';

export type AssetStatus = 'operational' | 'needs_service' | 'under_repair' | 'critical_down';
export type CriticalityTier = 'Tier 1 - Critical' | 'Tier 2 - Essential' | 'Tier 3 - Standard';

export interface Asset {
  id: string;
  facilityId: string;
  assetTag: string;
  name: string;
  category: AssetCategory;
  location: {
    building: string;
    floor: string;
    room: string;
    zone: string;
    coordinates?: { x: number; y: number }; // For floor plan pin
  };
  status: AssetStatus;
  criticality: CriticalityTier;
  manufacturer: string;
  model: string;
  serialNumber: string;
  installDate: string;
  warrantyExpiry: string;
  healthScore: number; // 0-100
  uptimePercentage: number;
  mtbfHours: number; // Mean time between failure
  mttrHours: number; // Mean time to repair
  runtimeHours: number;
  lastServiceDate: string;
  nextPmDueDate: string;
  specs: Record<string, string>;
  activeWorkOrderId?: string;
  qrCodeData: string;
}

export type WorkOrderPriority = 'emergency' | 'urgent' | 'routine' | 'low';
export type WorkOrderStatus = 'open' | 'in_progress' | 'waiting_parts' | 'completed' | 'verified';
export type WorkOrderType = 'corrective' | 'preventive' | 'inspection' | 'emergency';

export interface WorkOrderChecklistItem {
  id: string;
  task: string;
  completed: boolean;
  notes?: string;
}

export interface WorkOrderPartUsage {
  partId: string;
  partName: string;
  quantity: number;
  unitCost: number;
}

export interface WorkOrder {
  id: string;
  woNumber: string;
  facilityId: string;
  title: string;
  description: string;
  assetId: string;
  assetTag: string;
  assetName: string;
  location: string;
  zone: string;
  priority: WorkOrderPriority;
  status: WorkOrderStatus;
  type: WorkOrderType;
  assignedTechnician: {
    id: string;
    name: string;
    role: string;
  };
  requestedBy: string;
  createdAt: string;
  dueDate: string;
  slaHoursRemaining: number;
  laborHoursLogged: number;
  partsUsed: WorkOrderPartUsage[];
  checklist: WorkOrderChecklistItem[];
  failureCode?: string;
  technicianNotes?: string;
  signedOffBy?: string;
  signatureTimestamp?: string;
  completedAt?: string;
}

export interface PreventiveSchedule {
  id: string;
  facilityId: string;
  pmCode: string;
  title: string;
  assetId: string;
  assetTag: string;
  assetName: string;
  frequency: 'Daily' | 'Weekly' | 'Monthly' | 'Quarterly' | 'Semi-Annual' | 'Annual';
  nextDueDate: string;
  lastCompletedDate: string;
  estimatedMinutes: number;
  priority: WorkOrderPriority;
  assignedRole: string;
  complianceStandard: string;
  tasks: string[];
  status: 'upcoming' | 'due_soon' | 'overdue' | 'completed_cycle';
}

export interface SparePart {
  id: string;
  facilityId: string;
  partNumber: string;
  name: string;
  category: string;
  quantityInStock: number;
  minReorderPoint: number;
  unitCost: number;
  binLocation: string;
  supplier: string;
  leadTimeDays: number;
}

export interface Technician {
  id: string;
  name: string;
  role: string;
  certifications: string[];
  activeWOs: number;
  status: 'Available' | 'On Job' | 'Off Shift';
  phone: string;
}
