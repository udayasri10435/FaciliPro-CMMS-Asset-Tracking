import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Facility,
  Asset,
  WorkOrder,
  PreventiveSchedule,
  SparePart,
  Technician,
  WorkOrderStatus,
  WorkOrderPriority,
} from '../types/cmms';
import {
  INITIAL_FACILITIES,
  INITIAL_ASSETS,
  INITIAL_WORK_ORDERS,
  INITIAL_PREVENTIVE_SCHEDULES,
  INITIAL_SPARE_PARTS,
  INITIAL_TECHNICIANS,
} from '../data/mockData';

interface CMMSContextType {
  facilities: Facility[];
  currentFacilityId: string;
  setCurrentFacilityId: (id: string) => void;
  currentFacility: Facility;
  assets: Asset[];
  workOrders: WorkOrder[];
  preventiveSchedules: PreventiveSchedule[];
  spareParts: SparePart[];
  technicians: Technician[];
  isMobileFieldMode: boolean;
  setIsMobileFieldMode: (val: boolean) => void;
  
  // Work Order actions
  createWorkOrder: (wo: Omit<WorkOrder, 'id' | 'woNumber' | 'createdAt'>) => WorkOrder;
  updateWorkOrderStatus: (woId: string, status: WorkOrderStatus) => void;
  toggleChecklistItem: (woId: string, itemId: string) => void;
  addPartToWorkOrder: (woId: string, partId: string, quantity: number) => void;
  logLaborHours: (woId: string, hours: number) => void;
  signOffWorkOrder: (woId: string, signerName: string) => void;
  
  // Asset actions
  updateAssetStatus: (assetId: string, status: Asset['status']) => void;
  
  // PM actions
  generateWorkOrderFromPM: (pmId: string) => WorkOrder;
  
  // Inventory actions
  reorderSparePart: (partId: string, amount: number) => void;

  // Active Modals & Selected Items
  selectedWorkOrderId: string | null;
  setSelectedWorkOrderId: (id: string | null) => void;
  selectedAssetId: string | null;
  setSelectedAssetId: (id: string | null) => void;
  isCreateWoOpen: boolean;
  setIsCreateWoOpen: (open: boolean) => void;
  isQrScannerOpen: boolean;
  setIsQrScannerOpen: (open: boolean) => void;
  isFloorPlanOpen: boolean;
  setIsFloorPlanOpen: (open: boolean) => void;
  isComplianceReportOpen: boolean;
  setIsComplianceReportOpen: (open: boolean) => void;

  // Toast notification
  toastMessage: string | null;
  showToast: (msg: string) => void;
}

const CMMSContext = createContext<CMMSContextType | undefined>(undefined);

const STORAGE_KEY_PREFIX = 'facilipro_cmms_';

export const CMMSProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [facilities, setFacilities] = useState<Facility[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY_PREFIX}facilities`);
    return saved ? JSON.parse(saved) : INITIAL_FACILITIES;
  });

  const [currentFacilityId, setCurrentFacilityId] = useState<string>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY_PREFIX}current_fac`);
    return saved || 'fac-hosp';
  });

  const [assets, setAssets] = useState<Asset[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY_PREFIX}assets`);
    return saved ? JSON.parse(saved) : INITIAL_ASSETS;
  });

  const [workOrders, setWorkOrders] = useState<WorkOrder[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY_PREFIX}work_orders`);
    return saved ? JSON.parse(saved) : INITIAL_WORK_ORDERS;
  });

  const [preventiveSchedules, setPreventiveSchedules] = useState<PreventiveSchedule[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY_PREFIX}preventive`);
    return saved ? JSON.parse(saved) : INITIAL_PREVENTIVE_SCHEDULES;
  });

  const [spareParts, setSpareParts] = useState<SparePart[]>(() => {
    const saved = localStorage.getItem(`${STORAGE_KEY_PREFIX}spare_parts`);
    return saved ? JSON.parse(saved) : INITIAL_SPARE_PARTS;
  });

  const [technicians] = useState<Technician[]>(INITIAL_TECHNICIANS);
  const [isMobileFieldMode, setIsMobileFieldMode] = useState<boolean>(false);

  // Modals
  const [selectedWorkOrderId, setSelectedWorkOrderId] = useState<string | null>(null);
  const [selectedAssetId, setSelectedAssetId] = useState<string | null>(null);
  const [isCreateWoOpen, setIsCreateWoOpen] = useState<boolean>(false);
  const [isQrScannerOpen, setIsQrScannerOpen] = useState<boolean>(false);
  const [isFloorPlanOpen, setIsFloorPlanOpen] = useState<boolean>(false);
  const [isComplianceReportOpen, setIsComplianceReportOpen] = useState<boolean>(false);

  // Toast
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((prev) => (prev === msg ? null : prev));
    }, 3800);
  };

  // Sync to local storage
  useEffect(() => {
    localStorage.setItem(`${STORAGE_KEY_PREFIX}facilities`, JSON.stringify(facilities));
    localStorage.setItem(`${STORAGE_KEY_PREFIX}current_fac`, currentFacilityId);
    localStorage.setItem(`${STORAGE_KEY_PREFIX}assets`, JSON.stringify(assets));
    localStorage.setItem(`${STORAGE_KEY_PREFIX}work_orders`, JSON.stringify(workOrders));
    localStorage.setItem(`${STORAGE_KEY_PREFIX}preventive`, JSON.stringify(preventiveSchedules));
    localStorage.setItem(`${STORAGE_KEY_PREFIX}spare_parts`, JSON.stringify(spareParts));
  }, [facilities, currentFacilityId, assets, workOrders, preventiveSchedules, spareParts]);

  const currentFacility =
    facilities.find((f) => f.id === currentFacilityId) || facilities[0];

  const createWorkOrder = (
    woData: Omit<WorkOrder, 'id' | 'woNumber' | 'createdAt'>
  ): WorkOrder => {
    const nextNumber = 9100 + workOrders.length;
    const newWo: WorkOrder = {
      ...woData,
      id: `wo-${Date.now()}`,
      woNumber: `WO-26-${nextNumber}`,
      createdAt: new Date().toISOString(),
    };

    setWorkOrders((prev) => [newWo, ...prev]);

    // Update facility open count
    setFacilities((prev) =>
      prev.map((f) =>
        f.id === woData.facilityId ? { ...f, openWoCount: f.openWoCount + 1 } : f
      )
    );

    // Update asset status if emergency or urgent
    if (woData.priority === 'emergency' || woData.priority === 'urgent') {
      setAssets((prev) =>
        prev.map((a) =>
          a.id === woData.assetId
            ? {
                ...a,
                status: woData.priority === 'emergency' ? 'critical_down' : 'needs_service',
                activeWorkOrderId: newWo.id,
              }
            : a
        )
      );
    }

    showToast(`Work Order ${newWo.woNumber} dispatched to ${newWo.assignedTechnician.name}`);
    return newWo;
  };

  const updateWorkOrderStatus = (woId: string, newStatus: WorkOrderStatus) => {
    setWorkOrders((prev) =>
      prev.map((wo) => {
        if (wo.id !== woId) return wo;
        const isClosing = newStatus === 'completed' || newStatus === 'verified';
        return {
          ...wo,
          status: newStatus,
          completedAt: isClosing && !wo.completedAt ? new Date().toISOString() : wo.completedAt,
        };
      })
    );

    const targetWo = workOrders.find((w) => w.id === woId);
    if (targetWo && (newStatus === 'completed' || newStatus === 'verified')) {
      // Return asset to operational if no other open work order
      setAssets((prev) =>
        prev.map((a) =>
          a.id === targetWo.assetId
            ? {
                ...a,
                status: 'operational',
                lastServiceDate: new Date().toISOString().split('T')[0],
                healthScore: Math.min(100, a.healthScore + 8),
              }
            : a
        )
      );
    }

    showToast(`Status updated to ${newStatus.replace('_', ' ').toUpperCase()}`);
  };

  const toggleChecklistItem = (woId: string, itemId: string) => {
    setWorkOrders((prev) =>
      prev.map((wo) => {
        if (wo.id !== woId) return wo;
        const updatedChecklist = wo.checklist.map((item) =>
          item.id === itemId ? { ...item, completed: !item.completed } : item
        );
        return { ...wo, checklist: updatedChecklist };
      })
    );
  };

  const addPartToWorkOrder = (woId: string, partId: string, quantity: number) => {
    const part = spareParts.find((p) => p.id === partId);
    if (!part || part.quantityInStock < quantity) {
      showToast('Insufficient stock for this spare part');
      return;
    }

    // Deduct stock
    setSpareParts((prev) =>
      prev.map((p) =>
        p.id === partId ? { ...p, quantityInStock: p.quantityInStock - quantity } : p
      )
    );

    // Add to work order
    setWorkOrders((prev) =>
      prev.map((wo) => {
        if (wo.id !== woId) return wo;
        const existingIndex = wo.partsUsed.findIndex((p) => p.partId === partId);
        let updatedParts = [...wo.partsUsed];
        if (existingIndex >= 0) {
          updatedParts[existingIndex] = {
            ...updatedParts[existingIndex],
            quantity: updatedParts[existingIndex].quantity + quantity,
          };
        } else {
          updatedParts.push({
            partId: part.id,
            partName: part.name,
            quantity,
            unitCost: part.unitCost,
          });
        }
        return { ...wo, partsUsed: updatedParts };
      })
    );

    showToast(`Allocated ${quantity}x ${part.name} to Work Order`);
  };

  const logLaborHours = (woId: string, hours: number) => {
    setWorkOrders((prev) =>
      prev.map((wo) =>
        wo.id === woId ? { ...wo, laborHoursLogged: wo.laborHoursLogged + hours } : wo
      )
    );
    showToast(`Logged ${hours} labor hours`);
  };

  const signOffWorkOrder = (woId: string, signerName: string) => {
    const now = new Date().toISOString();
    setWorkOrders((prev) =>
      prev.map((wo) =>
        wo.id === woId
          ? {
              ...wo,
              status: 'verified',
              signedOffBy: signerName,
              signatureTimestamp: now,
              completedAt: wo.completedAt || now,
            }
          : wo
      )
    );
    showToast(`Work order digitally signed off by ${signerName}`);
  };

  const updateAssetStatus = (assetId: string, status: Asset['status']) => {
    setAssets((prev) =>
      prev.map((a) => (a.id === assetId ? { ...a, status } : a))
    );
    showToast(`Asset status updated to ${status}`);
  };

  const generateWorkOrderFromPM = (pmId: string): WorkOrder => {
    const pm = preventiveSchedules.find((p) => p.id === pmId);
    if (!pm) throw new Error('PM schedule not found');

    const asset = assets.find((a) => a.id === pm.assetId);
    const tech = technicians[0]; // Assign primary tech

    const newWo = createWorkOrder({
      facilityId: pm.facilityId,
      title: `${pm.frequency} PM: ${pm.title}`,
      description: `Preventive Maintenance cycle based on standard ${pm.complianceStandard}. Perform scheduled tasks and log measurements.`,
      assetId: pm.assetId,
      assetTag: pm.assetTag,
      assetName: pm.assetName,
      location: asset
        ? `${asset.location.building}, ${asset.location.floor}, ${asset.location.room}`
        : 'Plant Mechanical Zone',
      zone: asset?.location.zone || 'Mechanical Zone',
      priority: pm.priority,
      status: 'open',
      type: 'preventive',
      assignedTechnician: {
        id: tech.id,
        name: tech.name,
        role: tech.role,
      },
      requestedBy: 'Automated PM Scheduler',
      dueDate: new Date(Date.now() + 86400000 * 3).toISOString(),
      slaHoursRemaining: 72,
      laborHoursLogged: 0,
      partsUsed: [],
      checklist: pm.tasks.map((taskText, idx) => ({
        id: `pm-chk-${idx}`,
        task: taskText,
        completed: false,
      })),
    });

    // Update PM schedule last completed date simulation
    setPreventiveSchedules((prev) =>
      prev.map((p) =>
        p.id === pmId
          ? { ...p, status: 'upcoming', lastCompletedDate: new Date().toISOString().split('T')[0] }
          : p
      )
    );

    return newWo;
  };

  const reorderSparePart = (partId: string, amount: number) => {
    setSpareParts((prev) =>
      prev.map((p) =>
        p.id === partId ? { ...p, quantityInStock: p.quantityInStock + amount } : p
      )
    );
    showToast(`Purchase order placed: +${amount} units added to stock`);
  };

  return (
    <CMMSContext.Provider
      value={{
        facilities,
        currentFacilityId,
        setCurrentFacilityId,
        currentFacility,
        assets,
        workOrders,
        preventiveSchedules,
        spareParts,
        technicians,
        isMobileFieldMode,
        setIsMobileFieldMode,
        createWorkOrder,
        updateWorkOrderStatus,
        toggleChecklistItem,
        addPartToWorkOrder,
        logLaborHours,
        signOffWorkOrder,
        updateAssetStatus,
        generateWorkOrderFromPM,
        reorderSparePart,
        selectedWorkOrderId,
        setSelectedWorkOrderId,
        selectedAssetId,
        setSelectedAssetId,
        isCreateWoOpen,
        setIsCreateWoOpen,
        isQrScannerOpen,
        setIsQrScannerOpen,
        isFloorPlanOpen,
        setIsFloorPlanOpen,
        isComplianceReportOpen,
        setIsComplianceReportOpen,
        toastMessage,
        showToast,
      }}
    >
      {children}
    </CMMSContext.Provider>
  );
};

export const useCMMS = () => {
  const context = useContext(CMMSContext);
  if (!context) {
    throw new Error('useCMMS must be used within a CMMSProvider');
  }
  return context;
};
